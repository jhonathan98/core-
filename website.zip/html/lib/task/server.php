<?php
header('Content-Type: application/json');
require_once("../../Connections/database.php");
require_once("../recaptchalib.php");
require ("../functions.php");
error_reporting(E_ALL);
$valor=variable(4,1); 
$dominio = $valor[0];

// Register API keys at https://www.google.com/recaptcha/admin
$valor=variable(13,1);
$siteKey = $valor[0];

$valor=variable(19,1);
$secret = $valor[0];
// reCAPTCHA supported 40+ languages listed here: https://developers.google.com/recaptcha/docs/language
$lang = "es-419";
// The response from reCAPTCHA
$resp = null;
// The error code from reCAPTCHA, if any
$error = null;
$reCaptcha = new ReCaptcha($secret);

/*recuperar contraseña*/
if(post('action')!=null&&post('action')=="suscribir"){
    $email = "";
    $email = trim(post("suscribir"));    
    $db->select("registrado","correo_registrado","WHERE correo_registrado='{$email}' AND idr=2");   
    if ($db->num_rows() < 1) {        
		$prepend=array(
            "idr"=>2,
            "correo_registrado"=>$email,
        );
        $insert=$db->insert('registrado',$prepend);
        
        if($insert){
            response(array("msg"=>"1"), 200);
        }
        else{
            response(array("msg"=>"2"), 200);
        }            
    }else{
        response(array("msg"=>"3"), 200);
    }
}


/*guardar clasificado*/
if(post('action')!=null&&post('action')=="guardar_clasificado"){

    $fecha = time();
    $fecha_registro = date("y-m-d",$fecha);
    $datos = array(
        "nombre_matrix" => post('nombre_clasificado'),
        "referencia_matrix" => post('id_usuario'),
        "amigable_matrix" => limpiar_url(post('nombre_clasificado')),
        "id_categoria" => post('categoria_clasificado'),
        "descripcion_matrix" => post('descripcion_proyecto'),
        "contenido_matrix" => post('descripcion_proyecto'),
        "evento_matrix" => post('fecha_clasificado'),
        "mail_matrix" => post('correo_clasificado'),
        "id_idmo" => 49,
        "fecha_matrix" => $fecha_registro,
        "inventario_matrix" => 0,
        "estado_matrix" => 1
    );

    $db->insert("matrix", $datos);
    //echo $db->last_query();
    $id_generado = $db->insert_id;
    //echo "id_generado = ".$id_generado;
    foreach($_FILES as $file){ //Iteramos el arreglo de archivos
        if($file['name'] != ""){ //Si el archivo se paso correctamente continuamos

            $aux = explode(".", $file['name']);
            $nombre_cambiar = limpiar_url(post('nombre_clasificado')).$id_generado.".".$aux[count($aux)-1];
            $nombre_archivo = strtolower($nombre_cambiar);
            //echo "nombre_archivo = ".$nombre_archivo;
            copy($file["tmp_name"], "../../imagenes/clasificados/imagen1/".$nombre_archivo) ;
            
            
            include_once('../../admon/thumbnail.inc.php');            
            //grandes
            $thumb = new Thumbnail("../../imagenes/clasificados/imagen1/".$nombre_archivo);
            if($thumb->getCurrentHeight() > 1000){
                $thumb->resize(0, 1000);
                //$thumb->crop(0,0,720,252);
                $thumb->save("../../imagenes/clasificados/imagen1/".$nombre_archivo);
                $thumb->destruct();
            }

            $thumb = new Thumbnail("../../imagenes/clasificados/imagen1/".$nombre_archivo);
            if($thumb->getCurrentWidth() > 1000) {
                $thumb->resize(1000, 0);
                //$thumb->crop(0,0,720,252);
                $thumb->save("../../imagenes/clasificados/imagen1/".$nombre_archivo);
                $thumb->destruct();
            }

            //medianas
            $thumb = new Thumbnail("../../imagenes/clasificados/imagen1/".$nombre_archivo);
            if($thumb->getCurrentHeight() > 400) {
                $thumb->resize(0, 400);
                //$thumb->crop(0,0,720,252);
                $thumb->save("../../imagenes/clasificados/imagen1/mediana/".$nombre_archivo);
                $thumb->destruct();
            }else{
                $thumb->save("../../imagenes/clasificados/imagen1/mediana/".$nombre_archivo);
                $thumb->destruct();
            }

            $thumb = new Thumbnail("../../imagenes/clasificados/imagen1/mediana/".$nombre_archivo);
            if($thumb->getCurrentWidth() > 400) {
                $thumb->resize(400, 0);
                //$thumb->crop(0,0,720,252);
                $thumb->save("../../imagenes/clasificados/imagen1/mediana/".$nombre_archivo);
                $thumb->destruct();
            }

            // pequenas
            $thumb = new Thumbnail("../../imagenes/clasificados/imagen1/".$nombre_archivo);
            if($thumb->getCurrentHeight() > 128) {
                $thumb->resize(0, 128);
                //$thumb->crop(0,0,720,252);
                $thumb->save("../../imagenes/clasificados/imagen1/pequena/".$nombre_archivo);
                $thumb->destruct();
            }else{
                $thumb->save("../../imagenes/clasificados/imagen1/pequena/".$nombre_archivo);
                $thumb->destruct();
            }

            $thumb = new Thumbnail("../../imagenes/clasificados/imagen1/pequena/".$nombre_archivo);
            if($thumb->getCurrentWidth() > 167) {
                $thumb->resize(167, 0);
                //$thumb->crop(0,0,720,252);
                $thumb->save("../../imagenes/clasificados/imagen1/pequena/".$nombre_archivo);
                $thumb->destruct();
            }

            $datos = array(
                "img_matrix" => $nombre_archivo
            );

            $db->update("matrix", $datos, "WHERE id_matrix='".$id_generado."'");
            response(array("msg"=>"1"), 200);
        }
    }
}


/*contactenos*/
if(post('action')!=null && post('action')=="contacto"){
    $resp = $reCaptcha->verifyResponse($_SERVER["REMOTE_ADDR"], $_POST["g-recaptcha-response"]);    
    if($resp != null && $resp->success){

        $valor=variable(6,1); 
        $toAttend = $valor[0];

        $valor=variable(7,1); 
        $remitente = $valor[0];

        $subject = "Mensaje de Contacto desde Core +";
        $body = "<html>
                    <head>
                        <meta charset='utf-8'>
                        <title>".$subject."</title>
                    </head>
                    <body>
                        <div class='container' style = ' padding: 10px 50px; font-family: sans-serif; color: #757575; '>
                            <h2 class='titles' style=' display: block; color: #000; font-weight: 700; font-size: 30px; font-family: sans-serif;'>".$subject."
                            <span style = 'display: block; width: 100px; border: 0; border-top: 3px solid #fe6501; margin-top: 0; margin-bottom: 0; margin-top: 5px;'></span></h2>
                            <h4 class='subtitle' style = 'font-size: 24px; margin: 5px 0px;'>".post('nombre')."</h4>
                            <span class='correo' style = 'color: #fe6501; font-size: 16px; font-style: italic;'>".post('email')."</span><br>
                            <span class='correo' style = 'color: #fe6501; font-size: 16px; font-style: italic;'>".post('tema')."</span><br>
                            <br>
                            <h3 style = 'color: #fe6501; font-size: 18px; font-style: italic;'>".post('pregunta')."</h3>
                            <p style = 'margin: 0px;'>".post('mensaje')."</p>
                            <br>
                            <p class='foot'>Este mensaje fue generado por el sistema, por favor no responder</p>
                        </div>
                    </body>
                    </html>";

        $resultMsg = sendPHPMailer($toAttend, $subject, $body);
        
        if($resultMsg){
            response(array("msg"=>"1"), 200);
        }else{
            response(array("msg"=>"3"), 200);
        }
    }else{
        response(array("msg"=>"2"), 200);
    }
}

/**/
if(post('action')!=null && post('action')=="last-productos"){
    $page_number=filter_var(post('page'), FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
    $item_per_page = 12;
    $ordenamiento = post('ordenamiento');
    $condicion = post('condicion');
    $position = ($page_number * $item_per_page);
    $db->select("vproducto p, categoria c, categoria g","p.id_matrix, p.nombre_matrix, p.img_matrix, p.precio_matrix, p.descripcion_matrix, p.amigable_matrix, p.nuevo_matrix, c.amigable_categoria, c.de","WHERE p.id_categoria = c.id_categoria AND c.de = g.id_categoria $condicion $ordenamiento LIMIT ".$position." ,".$item_per_page);
    /*$db->select("vblog b, categoria c","b.nombre_matrix, b.img_matrix, b.fecha_matrix, b.amigable_matrix, c.amigable_categoria","WHERE b.id_categoria=c.id_categoria ORDER BY b.fecha_matrix DESC LIMIT ".$position." ,".$item_per_page);*/
    /*$db->last_query();*/
    $innerHtml = "";
    while ($arraypadre = $db->fetch_array()) {
        $cpadre[] = $arraypadre; 
    }    
    if(!empty($cpadre)){
        foreach ($cpadre as $row) {
            $innerHtml.='<li class="col-xs-12 col-sm-3 col-md-3 items">
                            <div class="cont">
                                <div class="contimg">
                                    <a href="'.$dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/">
                                        <img src="'.$dominio.'imagenes/producto/imagen1/pequena/'.$row['img_matrix'].'" alt="'.$row['nombre_matrix'].'" title="'.$row['nombre_matrix'].'">
                                    </a>
                                    <div class="animate option">
                                        <a href=""><i class="fa fa-plus"></i></a>
                                        <a href="" class="mit"><i class="fa fa-heart-o"></i></a>
                                        <a href=""><i class="fa fa-random"></i></a>
                                    </div>                          
                                </div>
                                <p>'.$row['nombre_matrix'].' <br>'.$row['referencia_matrix'].'</p>
                                <span>$'.number_format($row['precio_matrix']).'</span>
                                <a href="'.$dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/" class="animate add">Ver producto</a>
                            </div>
                        </li>';            
        }
    }       
    /*echo $innerHtml;*/
    response(array("news"=>$innerHtml), 200);
}

/**/
if(post('action')!=null && post('action')=="last-clasificados"){
    $condicion = post('condicion');
    $cant_tanda = post('cant_tanda');
    $db->select("vclasificados v, categoria c","v.id_matrix, v.nombre_matrix, v.amigable_matrix, v.referencia_matrix, v.descripcion_matrix, c.img","WHERE c.id_categoria = v.id_categoria AND v.estado_matrix = 1 ".$condicion." LIMIT ".$cant_tanda.", 18446744073709551615");
    /*$db->last_query();*/
    $innerHtml = "";
    while ($arraypadre = $db->fetch_array()) {
        $cpadre[] = $arraypadre; 
    }    
    if(!empty($cpadre)){
        foreach ($cpadre as $row) {
            $innerHtml.='<li class="col s12 m6 l3 items">
                            <div class="cont">
                                <a href="'.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod21/">
                                    <img src="'.$dominio.'imagenes/categoria/'.$row['img'].'" alt="'.$row['nombre_matrix'].'" title="'.$row['nombre_matrix'].'">
                                </a>
                                <h4>'.$row['nombre_matrix'].'</h4>
                                <p><b>Por:</b> <span>'.$row['referencia_matrix'].'</span></p>
                                <p class="txt">'.substr($row['descripcion_matrix'], 0, 125).'</p>
                            </div>
                        </li>';            
        }
    }       
    /*echo $innerHtml;*/
    response(array("news"=>$innerHtml), 200);
}

/**/
if(post('action')!=null && post('action')=="last-blog"){
    $ip = getRealIP();
    $condicion = post('condicion');
    $ordenamiento = post('ordenamiento');
    $cant_tanda = post('cant_tanda');
    $page_number = filter_var(post('page'), FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
    $position = ($page_number * $cant_tanda);
    $db->select("vblog v, categoria c","v.id_matrix, v.nombre_matrix, v.referencia_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month, v.descripcion_matrix, v.url_matrix, v.img_matrix, v.estado_matrix, v.inventario_matrix, v.abre_matrix, v.id_categoria, v.amigable_matrix"," WHERE v.id_categoria=c.id_categoria AND estado_matrix = 1 ".$condition." ".$ordenamiento." LIMIT ".$position.", ".$cant_tanda);
    /*$db->last_query();*/
    $innerHtml = "";
    while ($arraypadre = $db->fetch_array()) {
        $cpadre[] = $arraypadre; 
    }    
    if(!empty($cpadre)){
        foreach ($cpadre as $row) {
            $mes=$row['month'];
            $innerHtml.='<li class="items">
                            <div class="row">
                                <div class="col s12 m12 l5">
                                    <a href="'.$dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/">
                                        <img src="'.$dominio.'imagenes/blog/imagen1/'.$row['img_matrix'].'" alt="'.$row['nombre_matrix'].'" title="'.$row['nombre_matrix'].'">
                                    </a>
                                </div>
                                <div class="col s12 m12 l7">
                                    <h3>'.$row['nombre_matrix'].'</h3>
                                    <div class="conim">
                                        <img src="'.$dominio.'images/imguser.png" alt="" title=""> '.$row['referencia_matrix'].' <span>'.$row['day'].' '.$mesAbre[$mes].' '.$row['year'].'</span>
                                        <div class="plus">';
            /*buscar si tiene me gusta*/
            $db->select("relacion","id_relacion","WHERE de='{$row['id_matrix']}' AND con='{$ip}' AND id_tipo=101");                                             
            if($db->num_rows() <= 0){
                $innerHtml.='<img id="btn-me-gusta-'.$row['id_matrix'].'" src="'.$dominio.'images/plusico.png" onclick="meGusta(\''.$row['id_matrix'].'\', \''.$ip.'\')" alt="" title="">';
            }

            /*buscar cantidad de me gusta*/
            $row_total_me_gusta = 0;
            $db->select("relacion", "COUNT(id_relacion) as total_me_gusta", "WHERE de='{$row['id_matrix']}' AND id_tipo=101");
            /*$db->last_query();*/
            $row_total_me_gusta = $db->fetch_assoc();
                                            
            $innerHtml.='<span id="count-me-gusta-'.$row['id_matrix'].'">'.$row_total_me_gusta['total_me_gusta'].'</span>';
            
            $innerHtml.='</div>
                                    </div>
                                    <p>'.$row['descripcion_matrix'].'</p>
                                    <a href="'.$dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/" class="link">Leer Más</a>
                                </div>
                            </div>
                        </li>';            
        }
    }       
    /*echo $innerHtml;*/
    response(array("news"=>$innerHtml), 200);
}

/**/
if(post('action')!=null && post('action')=="last-evento"){
    $condicion = post('condicion');
    $ordenamiento = post('ordenamiento');
    $cant_tanda = post('cant_tanda');
    $page_number = filter_var(post('page'), FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);
    $position = ($page_number * $cant_tanda);
    $db->select("vevento v, categoria c", "v.id_matrix, v.nombre_matrix, v.amigable_matrix, v.img_matrix, v.descripcion_matrix, v.evento_matrix, v.ciudad_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month", "WHERE v.id_categoria = c.id_categoria ".$condition." ".$ordenamiento." LIMIT ".$position.", ".$cant_tanda);
    /*$db->last_query();*/
    $innerHtml = "";
    while ($arraypadre = $db->fetch_array()) {
        $cpadre[] = $arraypadre; 
    }    
    if(!empty($cpadre)){
        foreach ($cpadre as $row) {
            $mes=$row['month'];
            $innerHtml.='<li class="items col s12 m6 l4">
                            <div class="cont">
                                <div class="row">
                                    <div class="conimg col s12 m12 l4">
                                        <div class="imgbg" style="background-image: url('.$dominio.'imagenes/evento/imagen1/'.$row['img_matrix'].');"></div>
                                    </div>
                                    <div class="contxt col s12 m12 l8 animate">
                                        <h3>'.$row['nombre_matrix'].'</h3>
                                        <div class="contmacal">
                                            <div class="col s12 m12 l6">
                                                <img src="'.$dominio.'images/icomap1.png" alt="" title=""> <span>'.$row['ciudad_matrix'].'</span>
                                            </div>
                                            <div class="col s12 m12 l6">
                                                <img src="'.$dominio.'images/icomap2.png" alt="" title=""> '.$row['day'].' '.$mesAbre[$mes].' '.$row['year'].'
                                            </div>
                                        </div>
                                        <p>'.substr($row['descripcion_matrix'], 0, 145).'</p>
                                        <a href="'.$dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod73/" class="link">Leer Más</a>
                                        <div class="lifle">
                                            <a href="'.$dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod73/"><img src="'.$dominio.'images/flecharara.png" alt="'.$row['nombre_matrix'].'" title="'.$row['nombre_matrix'].'"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>';            
        }
    }       
    /*echo $innerHtml;*/
    response(array("news"=>$innerHtml), 200);
}

/**/
if(post('action')!= null && post('action') == "me-gusta"){
    $id = post("id");
    $ip = post("ip");
    $db->select("relacion","id_relacion","WHERE de = '{$id}' AND con = '{$ip}' AND id_tipo = 101");
    if ($db->num_rows() <= 0) {        
        $prepend=array(
            "de"=>$id,
            "con"=>$ip,
            "id_tipo"=>101
        );
        $insert = $db->insert('relacion', $prepend);
        
        if($insert){
            $db->select("relacion","COUNT(id_relacion) as total_me_gusta","WHERE de = '{$id}' AND con = '{$ip}' AND id_tipo = 101");
            $row = $db->fetch_assoc();
            $total_me_gusta = $row['total_me_gusta'];
            response(array("msg"=>"1", "total_me_gusta"=>$total_me_gusta), 200);
        }
        else{
            response(array("msg"=>"2"), 200);
        }            
    }else{
        response(array("msg"=>"3"), 200);
    }

}

/*
 * function de recibido y respuesta de datos asincronicos.
 * functiones necesarias para el funcionamiento del api rest de
 * recibido y respuesta del servidor
 */
function post($key){
    if ($_SERVER['REQUEST_METHOD']=='POST') {
      
        $toArray= _toArray(json_decode(file_get_contents("php://input")));
        if(is_null($toArray))
            $toArray= _toArray($_POST);
        
        if(array_key_exists($key, $toArray)){
            return _toArray($toArray[$key]);
        }else{
            return null;
        }
        
    }else{
        return null;
    }
}

function get($key){
    if ($_SERVER['REQUEST_METHOD']=='GET') {
        $toArray= $_GET;
        if(array_key_exists($key, $toArray)){
           
            return $toArray[$key];
        }else{
            return null;
        }
        
    }else{
        return null;
    }
}

function _toArray($obj){
    if (is_array($obj)) {
        foreach ($obj as $key => $value) {
            if (is_array($value)) {
                $obj[$key] = _toArray($value);
            }
            if ($value instanceof stdClass) {
                $obj[$key] = _toArray((array)$value);
            }
        }
    }
    if ($obj instanceof stdClass) {
        return _toArray((array)$obj);
    }
    return $obj;
}

function response($array,$code){
    
    http_response_code($code);
    echo  json_encode($array);
}
?>
<?php 
	session_start();
	require_once("../Connections/database.php");
	require ("../lib/functions.php");
	require ("../include/guardian.php");	
	switch ($_GET['cod']) {
		case 'departamentos':	
				// echo "string";
				$db->select("departamento","*","where codigo_pais = '$_GET[paisd]' order by nombre_departamento asc");		
				// echo $db->last_query();
				$recoda = array();
				while ($datos = $db->fetch_array()) {
					$recoda[] = $datos;
				}
				echo json_encode($recoda);
			break;
		case 'ciudads':
			// echo "string";
				$db->select("ciudad","*","where id_departamento = '$_GET[depatar]' order by nombre_ciudad asc");		
				// echo $db->last_query();
				$recoda = array();
				while ($datos = $db->fetch_array()) {
					$recoda[] = $datos;
				}
				echo json_encode($recoda);
			break;
		case 'subcategoria':
					$db->select("vcategoria_proyecto","*","where id_categoria = '$_GET[categoria]'  order by nombre_matrix asc");		
				// echo $db->last_query();
				$recoda = array();
				while ($datos = $db->fetch_array()) {
					$recoda[] = $datos;
				}
				echo json_encode($recoda);
			break;		
		case 'cerrarsesion':
			session_destroy();		
			break;
		default:
			# code...
			break;
	}

	switch ($_POST['cod']) {
		case 'inicio_facebook':			
			$db->select("registrado","*","where correo_registrado='$_POST[email]'");
			$numd = $db->num_rows();
			if ($numd==0) {
				$sexo = "F";
				if ($_POST['sexo']=="male") {
					$sexo = "M";
				}
				$dato = array(
					"idr"=>1,
					"nombre_registrado"=>$_POST['nombre'],
					"correo_registrado" => $_POST['email'],
					"sexo_registrado" => $sexo,
					"id_network" =>  $_POST['id'],
					"img_registrado" => $_POST['images']
				);
				$db->insert("registrado",$dato);
				$id = $db->insert_id;
				$_SESSION['id_core'] = $id;
				$_SESSION['nombre_core'] = $_POST['nombre'];
				$_SESSION['correo_core'] = $_POST['email'];
				echo 1;
			} else{						
				$datos = $db->fetch_array();				
				$db->consulta_s("UPDATE registrado set id_network='$_POST[id]', img_registrado='$_POST[images]' where id_registrado='$datos[id_registrado]'");				
				$_SESSION['id_core'] = $datos['id_registrado'];
				$_SESSION['nombre_core'] = $datos['nombre_registrado'];
				$_SESSION['correo_core'] = $datos['correo_registrado'];
				echo 2;
			}
			break;
		case 'inicio_google':
			$db->select("registrado","*","where correo_registrado='$_POST[email]'");
			$numd = $db->num_rows();
			if ($numd==0) {
				$sexo = "F";
				if ($_POST['sexo']=="male") {
					$sexo = "M";
				}
				$dato = array(
					"idr"=>1,
					"nombre_registrado"=>$_POST['nombre'],
					"correo_registrado" => $_POST['email'],
					"sexo_registrado" => $sexo,
					"id_google" =>  $_POST['id'],
					"img_google" => $_POST['imagen']
				);
				$db->insert("registrado",$dato);
				$id = $db->insert_id;
				$_SESSION['id_core'] = $id;
				$_SESSION['nombre_core'] = $_POST['nombre'];
				$_SESSION['correo_core'] = $_POST['email'];
				echo 1;
			} else{						
				$datos = $db->fetch_array();				
				$db->consulta_s("UPDATE registrado set id_google='$_POST[id]', img_google='$_POST[imagen]' where id_registrado='$datos[id_registrado]'");				
				$_SESSION['id_core'] = $datos['id_registrado'];
				$_SESSION['nombre_core'] = $datos['nombre_registrado'];
				$_SESSION['correo_core'] = $datos['correo_registrado'];
				echo 2;
			}
			break;
		case 'inicio_linke':
			$db->select("registrado","*","where correo_registrado='$_POST[email]'");
			$numd = $db->num_rows();
			if ($numd==0) { 
				$dato = array(
					"idr"=>1,
					"nombre_registrado"=>$_POST['nombre'],
					"correo_registrado" => $_POST['email'],				 
					"id_linke" =>  $_POST['id'],
				 
				);
				$db->insert("registrado",$dato);
				$id = $db->insert_id;
				$_SESSION['id_core'] = $id;
				$_SESSION['nombre_core'] = $_POST['nombre'];
				$_SESSION['correo_core'] = $_POST['email'];
				echo 1;
			} else{						
				$datos = $db->fetch_array();				
				$db->consulta_s("UPDATE registrado set id_linke='$_POST[id]'  where id_registrado='$datos[id_registrado]'");				
				$_SESSION['id_core'] = $datos['id_registrado'];
				$_SESSION['nombre_core'] = $datos['nombre_registrado'];
				$_SESSION['correo_core'] = $datos['correo_registrado'];
				echo 2;
			}
			break;
		case 'comprueba_twitter':
			$db->select("registrado","*","where twitter_registrado='$_POST[idtw]'");
			$numd = $db->num_rows();
			if ($numd==0) {			
				echo 1;
			} else{						
				$datos = $db->fetch_array();				
				$db->consulta_s("UPDATE registrado set img_google='$_POST[imagen]' where id_registrado='$datos[id_registrado]'");				
				$_SESSION['id_core'] = $datos['id_registrado'];
				$_SESSION['nombre_core'] = $datos['nombre_registrado'];
				$_SESSION['correo_core'] = $datos['correo_registrado'];
				echo 2;
			}
			break;
		case 'inicia_twitter':
			$db->select("registrado","*","where correo_registrado='$_POST[email]'");
			$numd = $db->num_rows();
			if ($numd==0) {	
				$dato = array(
					"idr"=>1,
					"nombre_registrado"=>$_POST['nombre'],
					"correo_registrado" => $_POST['email'],				
					"twitter_registrado" =>  $_POST['id'],
					"img_google" => $_POST['imagen']
				);
				$db->insert("registrado",$dato);
				$id = $db->insert_id;
				$_SESSION['id_core'] = $id;
				$_SESSION['nombre_core'] = $_POST['nombre'];
				$_SESSION['correo_core'] = $_POST['email'];
				echo 1;
			} else{						
				$datos = $db->fetch_array();				
				$db->consulta_s("UPDATE registrado set twitter_registrado='$_POST[id]', img_google='$_POST[imagen]' where id_registrado='$datos[id_registrado]'");				
				$_SESSION['id_core'] = $datos['id_registrado'];
				$_SESSION['nombre_core'] = $datos['nombre_registrado'];
				$_SESSION['correo_core'] = $datos['correo_registrado'];
				echo 2;
			}
			break;
		case 'megustaPro':
			$db->select("relacion","*","where id_tipo='104' and de='$_POST[idPro]' and con='$_SESSION[id_core]'");
			// echo $db->last_query();
			$num = $db->num_rows();
			if ($num==0) {
				$db->consulta_s("INSERT into relacion(id_tipo,de,con,cantidad) values(104,'$_POST[idPro]','$_SESSION[id_core]',1)");
				echo 1;
			} else{
				echo 2;
			}			
			break;
		case 'metDonaciones':
				$descripcion = "";
				$precio = "";
				if($_POST[tipo]==105){
				 	$descripcion = $_POST[txtInsumo];
					$precio = $_POST[valInsum];
				}
				if($_POST[tipo]==107){
					$descripcion = $_POST[txtTrab];
					$precio = $_POST[valiTrabj];
				}
				if($_POST[tipo]==106){
					$precio = $_POST[valDonac];
				}
				$db->consulta_s("INSERT into donaciones(usuario,proyecto,tipo,descripcion,valor,estado,fecha_donacion, recompensa) 
					values('$_SESSION[id_core]','$_POST[idPro]','$_POST[tipo]','$descripcion','$precio',5,'".date("Y-m-d H:m:s")."', '$_POST[idreco]')");
				echo 1;		 			
			break;
		case 'filtroform':
			 $_SESSION['filtro']=$_POST['dato'];
			break;
		case 'comentarios':
			$datos = array(
				"comentario"=>$_POST['comentario'],
				"fecha_comentario"=>date("Y-m-d H:m:s"),
				"id_registrado"=>$_SESSION['id_core'],
				"id_maestra"=>$_POST['id'],
				"estado_comentario"=>1
			); 
			$db->insert("comentario",$datos);
 
			break;
		default:
			# code...
			break;
	}
?>
<?php
    include "include/includes.php";
    include "recaptchalib.php";

	if (isset($_POST['creaproyecto'])) {


		$secret = "6LeLESEUAAAAABff3jyl7vTULiAjwbRJYtDmb-62";

		$response = null;

		$reCaptcha = new ReCaptcha($secret);

		// if submitted check response
		if ($_POST["g-recaptcha-response"]) {
		    $response = $reCaptcha->verifyResponse(
		        $_SERVER["REMOTE_ADDR"],
		        $_POST["g-recaptcha-response"]
		    );
		}

		//if ($response != null && $response->success) {
			if ($_POST) {

			$fecha = date("Y-m-d");
			$datos = array(
				//cont1
				"id_registrado"         		=>$_SESSION['id_core'],
				"nombre_proyecto"				=>$_POST['nombre_proyecto'],
				"categoria_proyecto"			=>$_POST['categoria_proyecto1'],
				"descripcion_proyecto"			=>$_POST['descripcion_proyecto'],
				"fase_proyecto"					=>$_POST['fase_proyecto'],
				"pais_proyecto"					=>$_POST['pais_proyecto'],
				"departamento_proyecto"			=>$_POST['departamento_proyecto'],
				"ciudad_proyecto"				=>$_POST['ciudad_proyecto'],

				//cont2
				"cliente_proyecto"            	=>$_POST['cliente_proyecto'],
				"problema_proyecto"				=>$_POST['problema_proyecto'],
				"solucion_proyecto"				=>$_POST['solucion_proyecto'],
				"ventaja_proyecto"				=>$_POST['ventaja_proyecto'],
				"propuesta_proyecto"			=>$_POST['propuesta_proyecto'],
				"fuente_proyecto" 				=>$_POST['fuente_proyecto'],

				//cont3
				"costos_proyecto"				=>$_POST['costos_proyecto'],
				"valor_proyecto"				=>$_POST['valor_proyecto'],
				"plazo_financiacion_proyecto"	=>$_POST['plazo_financiacion_proyecto'],
				"nombre_recompensa1"			=>$_POST['nombre_recompensa'],
				"descripcion_recompensa1"		=>$_POST['descripcion_recompensa'],
				"valor_recompensa1"				=>$_POST['valor_recompensa'],
				"plazo_recompensa1"				=>$_POST['plazo_recompensa'],
				"envio_recompensa1"				=>$_POST['envio_recompensa'],
				"numero_recompensa1"			=>$_POST['numero_recompensa'],

				"nombre_recompensa2"			=>$_POST['nombre_recompensa2'],
				"descripcion_recompensa2"		=>$_POST['descripcion_recompensa2'],
				"valor_recompensa2"				=>$_POST['valor_recompensa2'],
				"plazo_recompensa2"				=>$_POST['plazo_recompensa2'],
				"envio_recompensa2"				=>$_POST['envio_recompensa2'],
				"numero_recompensa2"			=>$_POST['numero_recompensa2'],

				"nombre_recompensa3"			=>$_POST['nombre_recompensa3'],
				"descripcion_recompensa3"		=>$_POST['descripcion_recompensa3'],
				"valor_recompensa3"				=>$_POST['valor_recompensa3'],
				"plazo_recompensa3"				=>$_POST['plazo_recompensa3'],
				"envio_recompensa3"				=>$_POST['envio_recompensa3'],
				"numero_recompensa3"			=>$_POST['numero_recompensa3'],

				//cont4
				"descripcion_equipo"		=>$_POST['descripcion_equipo'],


				//cont5
				"video_proyecto"				=>$_POST['video_proyecto'],
				"descripcion_extra"				=>$_POST['descripcion_extra'],
				//"documento_extra"				=>$_FILES[documento_extra],
				"fecha_publicacion"				=>$fecha,



			);



			$db->insert("proyecto",$datos);
			//$valor = $db->last_query();
			$idp = $db->insert_id;



			$string = $_POST[hdequipo];
			$user = (array)json_decode($string);
			//echo $user;


			$string = $_POST[hdrecompensas];
			$user = (array)json_decode($string);
			//echo $user;
			foreach($user['items'] as $key=>$val){
				 $datosrecompensa = array(

				 "recompensa"           => $val->recompensa,
				 "descripcion"          => $val->descripcion,
				 "monto_recompensa"     => $val->monto_recompensa,
				 "fecha_recompensa"     => $val->fecha_recompensa,
				 "envio_recompensa"     => $val->envio_recompensa, //
				 "num_recompensa"    => $val->numero_recompensa,
				 "idproyecto"           => $idp
				 );
				 $db->insert("proyectoxrecompensa",$datosrecompensa);
			}

			//Nombre archivo
			$archivo = $_FILES["documento_extra"]['name'];

			//Extencion de archivo
			$datos 	= explode(".", $archivo);
			$ext 	= end($datos);
			$tamano = $_FILES["documento_extra"]['size'];
			$tipo 	= $_FILES["documento_extra"]['type'];

			if ($archivo != "") {
				//nombre archivo personalizado
				$nombre_ar 	= $idp."_documento.".$ext;
				$destino 	= "proyectos/docs/".$nombre_ar;
				//Seguarda el archivo en la ruta y nombre especificado
				if (copy($_FILES['documento_extra']['tmp_name'],$destino))
				{
					$respuestareg = 1;
					$db->consulta_s("UPDATE proyecto set documento_extra='$nombre_ar' where id_proyecto='$idp'");
					//$db->UPDATE("proyecto", "set documento_extra=$nombre_ar"," where id_proyecto=$idp");
				}
			}

			// carga imagenes
			$imgs = $_FILES['galeria_proyecto']['name'];
			$imgnum = count($imgs);

			if ($imgnum>0) {
				$imgs = $_FILES['galeria_proyecto'];

				 for ($i=0; $i < $imgnum; $i++) {

					$archivo = $_FILES["galeria_proyecto"]['name'][$i];

					//Extensión de archivo
					$datos 	= explode(".", $archivo);
					$ext 	= end($datos);


					$tamano = $_FILES["galeria_proyecto"]['size'][$i];
					$tipo 	= $_FILES["galeria_proyecto"]['type'][$i];

					if ($archivo != "") {
						//nombre archivo personalizado
						$nombre_ar = $idp."_imagenes.".$ext;
						//Ruta donde se guarda el archivo
						$destino = "proyectos/img/".$nombre_ar;
						//Seguarda el archivo en la ruta y nombre especificado
						if (copy($_FILES['galeria_proyecto']['tmp_name'][$i],$destino)) {
							$respuestareg = 1;
							$vector = array(
					 	 		"id_proyecto"	=>$idp,
					 	 		"ruta_imagen"	=>$destino
					 	 );
					 	$db->insert("imagenes_proyecto",$vector);

						}
					}
				}
			}else{
				echo "error";
			}

?>
	        <script type="text/javascript">
	            $(window).load(function(){
	                swal({
	                  title: "Correcto!",
	                  text: "Su proyecto se creo exitosamente.",
	                  type: "success",

	                },
	                function(){
	                  location.href="<?php echo $dominio ?>";
	                });
	 			 });
	        </script>
<?php
		}
	}
?>

    <script type="text/javascript">
        $(document).ready(function(){
            $("#form-proyecto").submit(function(){
            	console.log("submit form-proyecto");
                if (!vacios("#form-proyecto")) {return false;}
            })
        });
    </script>
</head>
<body>
	<?php include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container">
			<h1>INICIAR NUEVO PROYECTO</h1>
		</div>
	</div>
	<br>
	<div class="titlesgds">


		<span id="spa1" class="active">DATOS BASICOS</span>  <span id="spa2">MODELO DE NEGOCIO</span>  <span id="spa3">RECOMPENSA</span>  <span id="spa4">EQUIPO DE TRABAJO</span>  <span id="spa5">MULTIMEDIA E INFORMACION</span>
	</div>
	<div class="conproyect" ng-controller="proyectoController" id="conproghtyrgha">
		<div class="container">

			<form class="contform" id="form-proyecto" action="" method="post" enctype="multipart/form-data">

				<div id="cont1">

					<div class="input-field">
						<label for="nomproyec">Nombre del proyecto  <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(1, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<input type="text" for="nomproyec" placeholder="Nombre del proyecto" name="nombre_proyecto" id="nombre_proyecto" class="required">
					</div>

					<div class="input-field">
						<label for="catepriprot">Categoría principal del proyecto <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(2, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<select id="categoria1" for="catepriprot" name="categoria_proyecto1" id="categoria_proyecto1" onchange="buscSubcategorias(this, 1)" >
							<option value="">Seleccionar categoría</option>
							<?php
								$db->select("categoria","*","where modulo=59 order by nombre_categoria asc");
								while ($datos = $db->fetch_array()) {
								?>
								<option value="<?php echo $datos[id_categoria] ?>"><?php echo $datos[nombre_categoria] ?></option>
							<?php
								}
							?>
						</select>
					</div>

					<!--div class="input-field">
						<label for="subcate">Subcategoría <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(3, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<select for="subcate" name="subcategoria_proyecto" id="subcategoria1">
							<option>Seleccionar subcategoría</option>
						</select>
					</div-->
					<div class="input-field">
						<label for="subcate">Descripción <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(4, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="descripcion_proyecto" id="descripcion_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="input-field">
						<label for="fasepro">Fase del proyecto <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(74, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<select for="fasepro" name="fase_proyecto" id="fase_proyecto">
							<option value="">Seleccionar fase</option>
							<?php
								$db->select("tipo","*","where idr=39 order by nombre_tipo asc");
								while ($datos = $db->fetch_array()) {
							?>
								<option value="<?php echo $datos[id_tipo] ?>"><?php echo $datos[nombre_tipo] ?></option>
							<?php
								}
							?>
						</select>
					</div>
					<div class="input-field">
						<label for="fasepro">País <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(5, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<select for="fasepro" ng-model="spais" name="pais_proyecto" id="pais_proyecto" ng-change="buscDepartamento(spais, 1)" >
							<option value=""> Seleccionar país  </option>
							<?php
								$db->select("pais","*","order by nombre_pais asc");
								while ($datos = $db->fetch_array()) {
							?>
								<option value="<?php echo $datos['codigo_pais'] ?>"><?php echo $datos['nombre_pais'] ?></option>
							<?php
								}
							?>
						</select>
					</div>
					<div class="input-field">
						<label for="faseprod">Departamento <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(6, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<select for="faseprod" id="departamento1" ng-model="sdepart" id="departamento_proyecto" name="departamento_proyecto" onchange="buscCiudad(this, 1)" >
							<option value="">seleccionar departamento</option>
						</select>
					</div>
					<div class="input-field">
						<label for="fasepro">Ciudad <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(7, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<select for="fasepro" name="ciudad_proyecto" id="ciudad1">
							<option>Seleccionar ciudad</option>
						</select>
					</div>


					<div class="botones center-align">
						<button type="button" rel="2"  class="btn siguiente">Siguiente >></button>
            <!--a href="#" class="disparador">Continuar despues</a!-->
					</div>
				</div>

				<div id="cont2" style="display:none;">
					<div class="input-field">
						<label for="subcate">Cliente <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(75, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="cliente_proyecto" id="cliente_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Problema <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(11, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="problema_proyecto" id="problema_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Solución <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(12, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="solucion_proyecto" id="solucion_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Ventaja Competitiva <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(13, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name ="ventaja_proyecto" id="ventaja_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Propuesta de valor <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(14, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="propuesta_proyecto" id="propuesta_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<!--div class="input-field">
						<label for="subcate">Canales <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(15, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="canales_proyecto" id="canales_proyecto" class="materialize-textarea required"></textarea>
					</div-->
					<!--div class="input-field">
						<label for="subcate">M&eacute;tricas <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(16, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="metricas_proyecto" id="metricas_proyecto" class="materialize-textarea required"></textarea>
					</div-->
					<div class="input-field">
						<label for="subcate">Fuentes de ingresos <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(17, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="fuente_proyecto" id="fuente_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="botones center-align">
						<button type="button" rel="1" class="btn anterior"><< Anterior</button>
						<button type="button" rel="3" class="btn siguiente">Siguiente >></button>
            <!--a href="#" class="disparador">Continuar despues</a-->

					</div>
				</div>

				<div id="cont3" style="display: none;">


					<div class="input-field">
						<label for="subcate">Estructuras de costos/ Meta de los recursos <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(18, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="costos_proyecto" id="costos_proyecto" class="materialize-textarea required"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Valor total <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(19, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<input type="number" rel="" name="valor_proyecto" id="valor_proyecto" placeholder="Valor total del proyecto" class="required" onkeyup="otronumber(this.value)" min="1000">
					</div>
					<div class="input-field">
						<label for="subcate">Fecha de plazo de financiación <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(76, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<input type="date" id="plazo_financiacion_proyecto" class="datepicker required" name="plazo_financiacion_proyecto"  placeholder="Fecha financiación">
					</div>

					<div class="botones center-align">
						<button type="button" rel="2" id="abrirpopup" class="btn anadirbtn">Añadir Recompensa</button>
					</div>
					<br>
					 <table id="tablarecompensa" class="bordered">

				        <thead>
				          <tr>
				              <th>Recompensa</th>
				              <th>Descripcion</th>
				              <th>Monto</th>
				              <th>Fecha</th>
				              <th>Envio</th>
				              <th>Numero</th>
				              <th>Accion</th>
				          </tr>
				        </thead>
				        <tbody>
				        </tbody>

      				</table>
      				<div style="display:none">
							<div class="input-field">
								<label for="subcate">Recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(21, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" name="nombre_recompensa" class="materialize-textarea "></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Descripción <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(22, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" name="descripcion_recompensa" class="materialize-textarea "></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Monto de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(23, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<input type="number" rel="" name="valor_recompensa" placeholder="Monto de la recompensa"  onkeyup="otronumber(this.value)" >
							</div>
							<div class="input-field">
								<label for="subcate">Fecha de entrega de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(24, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<input type="date" name="plazo_recompensa" class="datepicker"></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Envío recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(25, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" name="envio_recompensa" class="materialize-textarea "></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Establecer número de recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(26, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="" name="numero_recompensa" class="materialize-textarea "></textarea>
							</div>
					</div>

				<!--Recomenpsa2-->
				<div class="reco2" style="display:none">
					<div class="input-field">
						<label for="subcate">Recompensa número 2 <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(27, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="nombre_recompensa2" class="materialize-textarea"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Descripción <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(28, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="descripcion_recompensa2" class="materialize-textarea"></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Monto de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(29, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<input type="number" rel="" name="valor_recompensa2" onkeyup="otronumber(this.value)" >
					</div>
					<div class="input-field">
						<label for="subcate">Fecha de entrega de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(30, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<input type="date" name="plazo_recompensa2" class="datepicker "></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Envío recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(31, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="envio_recompensa2" class="materialize-textarea "></textarea>
					</div>
					<div class="input-field">
						<label for="subcate">Establecer número de recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(32, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="" name="numero_recompensa2" class="materialize-textarea "></textarea>
					</div>
				</div>

						<!--Recompensa N3-->
						<div class="reco3" style="display:none">
							<div class="input-field">
								<label for="subcate">Recompensa número 3 <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(33, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" name="nombre_recompensa3" class="materialize-textarea "></textarea>
							</div>
								<div class="input-field">
								<label for="subcate">Descripción <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(34, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" name="descripcion_recompensa3" class="materialize-textarea "></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Monto de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(35, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<input type="number" rel="" name="valor_recompensa3"  onkeyup="otronumber(this.value)" >
							</div>
							<div class="input-field">
								<label for="subcate">Fecha de entrega de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(36, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<input type="date" name="plazo_recompensa3" class="datepicker"></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Envío recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(37, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" name="envio_recompensa3" class="materialize-textarea"></textarea>
							</div>
							<div class="input-field">
								<label for="subcate">Establecer número de recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(38, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="" name="numero_recompensa3" class="materialize-textarea"></textarea>
							</div>
					   </div>
					   <br>
					   <div class="input-field">
								<label for="nomproyec">Modo de financiación<a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(39, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a> </label>
								<!-- <input  rel="numi" type="number" for="nomproyec" name="financiacion_proyecto" placeholder="Financiación"  class="required" onkeyup="otronumber(this.value)"> -->
								<p>
									<input type="radio" name="financiacion_proyecto" value="1" class="filled-in" id="filled-in-box"  />
		      						<label for="filled-in-box">TODO SUMA</label>
		      					</p>
		      					<p>
		      						<input type="radio" name="financiacion_proyecto" value="2" class="filled-in" id="filled-in-box2"   />
		      						<label for="filled-in-box2">TODO O NADA</label>
		      					</p>

					   </div>
					   <div class="botones center-align">
					      <input type="hidden" id="hdrecompensas" name = "hdrecompensas" value="">
					   	  <button type="button" rel="2" class="btn anterior"><< Anterior</button>
					   	  <button type="button" rel="4" class="btn siguiente">Siguiente >></button>
                <!--a href="#" class="disparador">Continuar despues</a-->

					   </div>

			</div>

				<div id="cont4" style="display: none;">
					<br>
				    <div class="botones center-align">
					</div>

					<br>
					<div class="input-field">
						<label for="subcate">Describe a tu equipo <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(38, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="" name="descripcion_equipo" class="materialize-textarea"></textarea>
					</div>


					<br>
					<div class="botones center-align">
					     <input type="hidden" id="hdequipo" name = "hdequipo" value="">
						<button type="button" rel="3" class="btn anterior"><< Anterior</button>
						<button type="button" rel="5" class="btn siguiente">Siguiente >></button>
            <!--a href="#" class="disparador">Continuar despues</a-->

					</div>
				</div>

				<div id="cont5" style="display: none;">
				<!--Video-->
					<div class="input-field">
						<label for="subcate">Video corto del proyecto <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(54, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<input type="text" rel="url" name="video_proyecto" class="required" placeholder="URL del video">
					</div>
				<!--Galeria-->
					<div class="input-field">
						<label for="subcate">Galería Fotográfica prototipos o productos finalizados. <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(55, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<div class="file-field input-field">
							<div class="btn">
								<span>subir</span>
								<input name="galeria_proyecto[]" type="file" onchange="handleFileSelect(event);" multiple>
							</div>
							<div class="file-path-wrapper">
								<input type="text" class="file-path validate" >
							</div>
						</div>
					</div>
					<div class="txtcargimj"></div>
					<div class="cargaimagen"></div>
				<!--Descripcion-->
					<div class="input-field">
						<label for="subcate">Descripción para colocar más datos, de cómo se empleara el dinero, las fases o la planeación o proyección que se tiene del proyecto. <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(56, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<textarea rel="textarea" name="descripcion_extra" id="descripcion_extra" class="materialize-textarea required"></textarea>
					</div>
				<!--Documentos-->
					<div class="input-field">
						<label for="subcate">Documentos o archivos de soporte <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(57, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
						<div class="file-field input-field">
							<div class="btn">
								<span>subir</span>
								<input type="file" name="documento_extra">
							</div>
							<div class="file-path-wrapper">
								<input type="text" class="file-path validate"  >
							</div>
						</div>
					</div>

				<!--Captcha-->
				<div class="botones center-align input-field">
					<input type="hidden" name="creaproyecto" value="creaproyecto">
					<button type="button" rel="4" class="btn anterior"><< Anterior</button>
					<button class="btn" type="submit"  name="form-contacto">Guardar proyecto</button>
          <!--a href="#" class="disparador">Continuar despues</a-->

				</div>

				</div>

			</form>
		</div>

	</div>
  	<div id="basic" style="display: none;  border:3px solid #B2B2B2 !important;" class="modal modal-fixed-header" style="max-width:44em;">
        <div class="contform" id="form-proyecto2" >
		   	 <div class="modal-content">
			    <div class="row">
				        <form class="col s12">
				          <div class="row modal-form-row">

				          <div class="row">
				            <div class="input-field col s12">
				                <label for="subcate">Recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(21, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" id="nombre_recompensa" class="materialize-textarea"></textarea>
				            </div>
				          </div>


				          <div class="row">
				            <div class="input-field col s12">
				                <label for="subcate">Descripción <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(22, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
								<textarea rel="textarea" id="descripcion_recompensa"  class="materialize-textarea"></textarea>
				            </div>
				          </div>

				          <div class="row">
				            <div class="input-field col s12">
				            		<label for="subcate">Monto de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(23, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<input type="number" rel="" id="valor_recompensa"  placeholder="Monto de la recompensa"  onkeyup="otronumber(this.value)" >
				            </div>
				          </div>

				          <div class="row">
				            <div class="input-field col s12">
				            		<label for="subcate">Fecha de entrega de la recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(24, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<input type="date" id="plazo_recompensa"  class="datepicker"></textarea>
				            </div>
				          </div>

				          <div class="row">
				            <div class="input-field col s12">
				            		<label for="subcate">Envío recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(25, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<textarea rel="textarea" id="envio_recompensa" class="materialize-textarea"></textarea>
				            </div>
				          </div>

				           <div class="row">
				            	<div class="input-field col s12">
				            		<label for="subcate">Establecer número de recompensa <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(26, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<textarea rel="" id="numero_recompensa"  class="materialize-textarea"></textarea>
				          	   </div>
				          </div>
				          </div>
				        </form>
				    </div>
		     </div>
		     <div class="modal-footer">
					  <a class=" modal-action modal-close waves-effect waves-green btn-flat" id="saverecompensa">Guardar</a>
			 </div>
		</div>
	</div>


	<div id="divequipo" style="display: none; border:3px solid #B2B2B2 !important;" class="modal" style="max-width:44em;">
        <div class="contform" id="form-proyecto3" >
		   	 <div class="modal-content">

		   	 	<div class="row">
		   	 		 <form class="col s12">
		   	 		 	<div class="row modal-form-row">
		   	 		 		<div class="row">
					            <div class="input-field col s12">
					                <label for="subcate">Correo de contacto proyecto <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(40, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<input type="text" rel="email" id="correo_contacto_proyecto" class="required">
					            </div>
				            </div>

				            <div class="row">
					            <div class="input-field col s12">
					                <label for="subcate">Nombre contacto <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(41, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<input type="text" id="nombre_contacto" class="required">
					            </div>
				            </div>

				            <div class="row">
				               <div class="input-field col s12">
				            		<label for="subcate">C&eacute;dula <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(42, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<input type="text" rel="numerico" id="cedula_contacto" class="required">
				               </div>
				            </div>

				            <div class="row">
					            <div class="input-field col s12">
					            		<label for="subcate">Fijo <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(43, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
										<input type="text" rel="phone" id="fijo_contacto" class="required">
					            </div>
				           </div>

				           <div class="row">
					            <div class="input-field col s12">
					            		<label for="subcate">Celular <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(44, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
										<input type="text" rel="phone" id="celular_contacto" class="required">
					            </div>
				           </div>

				           <div class="row">
				            	<div class="input-field col s12">
				            		<label for="subcate">Nacimiento <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php //$valor = idioma(45, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<input type="date" id="nacimiento_contacto" class="datepicker required"></textarea>
				          	   </div>
				          </div>

				           <div class="row">
				            	<div class="input-field col s12">
				            		<label for="fasepro">País <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(46, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<select for="fasepro" ng-model="spais2" id="pais_contacto_proyectopopup" ng-change="buscDepartamento(spais2, 22)" >
										<option value=""> Seleccionar país  </option>
										<?php
											$db->select("pais","*","order by nombre_pais asc");
											while ($datos = $db->fetch_array()) {
										?>
											<option value="<?php echo $datos['codigo_pais'] ?>"><?php echo $datos['nombre_pais'] ?></option>
										<?php
											}
										?>
									</select>
				          	   </div>
				          </div>
				          <div class="row">
				            	<div class="input-field col s12">
				            		<label for="faseprod">Departamento <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(47, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
									<select for="faseprod" id="departamento22" ng-model="sdepart"  onchange="buscCiudad(this, 22)" >
										<option value="">seleccionar departamento</option>
									</select>
				          	   </div>
				          </div>

				          <div class="row">
				            	<div class="input-field col s12">
				            			<label for="fasepro">Ciudad <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php $valor = idioma(48, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
										<select for="fasepro"  id="ciudad22">
											<option>Seleccionar ciudad</option>
										</select>
				          	   </div>
				          </div>


				          <div class="row">
				            	<div class="input-field col s12">
				            			<label for="subcate">Codigo postal <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php //$valor = idioma(49, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
										<input type="text" rel="numerico" id="postal_contacto" class="required">
				          	   </div>
				          </div>

				           <div class="row">
				            	<div class="input-field col s12">
				            			<label for="subcate">Individuo o entidad legal <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php //$valor = idioma(50, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
										<input type="text" id="legal_contacto" class="required">
				          	   </div>
				          </div>

				          <div class="div1">
				          	   <div class="row">
				            	<div class="input-field col s12">
				            				<label for="subcate">Nit <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php //$valor = idioma(52, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
											<input type="text" id="nit_contacto" class="required">
				          	   </div>
				          </div>
				          </div>

				           <div class="row">
				            	<div class="input-field col s12">
				            				<label for="subcate">Tipo de negocio <a class="tooltipped" data-position="top" data-delay="50" data-tooltip="<?php //$valor = idioma(51, $idioma, 117); echo $valor[0]; ?>"><i class="fa fa-question"></i></a></label>
											<input type="text" id="tipo_negocio" class="required">
				          	   </div>
				          </div>




		   	 		 	 </div>
		   	 		 </form>

			    </div>
		     </div>
		     <div class="modal-footer">
					  <a class=" modal-action modal-close waves-effect waves-green btn-flat" id="savecontacto">Guardar</a>
			 </div>
		</div>
	</div>
	<br><br><br>

	<?php include "include/footer.php"; ?>

	<!--<script src="https://www.google.com/recaptcha/api.js?hl=es" async defer></script>-->
	<script type="text/javascript">


	   //$("#form-proyecto").validate();
		/*Segun el checkbox presionadohacer que cambien y se agreguen o en tal caso se eliminen unos campsos revisar por que no funciona
	   $('#indiv1').change(function(){

	   		if (this.checked) {
	   			$('#div1').fadeIn('slow');
			else
			$('#div1').fadeOut('slow');
	   		}

	   });


	   $('#indiv2').change(function(){

	   		if (this.checked) {
	   			$('#div2').fadeIn('slow');
			else
			$('#div2').fadeOut('slow');
	   		}

	   });*/
     $(".disparador").click(function(){
       $.ajax({
          data:$("#form-proyecto").serialize() ,

          url:   dominio+'sinterminar.php',
          type:  'POST',
          beforeSend: function(){},
          success:  function (response) {
            console.log(response);

            //mensaje = "Mensaje enviado correctamente.";
            // swal('Proceso exitoso!', mensaje, 'success');

            }
        });
     });

		$(document).ready(function () {
			$('#basic').popup();
		});

		ang.controller('proyectoController', function($scope, $http) {

		    $scope.buscDepartamento = function(dat,b){

		    	$scope.departamentos = [];
		    	$("#departamento"+b).html("<option value=''>Seleccionar</option>");
		    	$.get(dominio+'lib/ajax_hlo.php',{"cod":"departamentos", "paisd":dat},function(response){
		    		var itm = JSON.parse(response);

			    		$.each(itm,function(p,a){
			    			$("#departamento"+b).append("<option value='"+a.id_departamento+"'>"+a.nombre_departamento+"</option>");
			    		});

		    		})
		    	}

		})

		buscCiudad = function(dats,b){

			dats = $("#departamento"+b).val();
			$("#ciudad"+b).html("<option value=''>Seleccionar</option>");
			$.get(dominio+'lib/ajax_hlo.php',{"cod":"ciudads", "depatar":dats},function(response){
				var itm = JSON.parse(response);
				$.each(itm,function(p,a){
					$("#ciudad"+b).append("<option value='"+a.id_ciudad+"'>"+a.nombre_ciudad+"</option>");
					})
				})
		}


		buscSubcategorias = function(dats,b){

			console.log(b);
			dats = $("#categoria"+b).val();
			console.log(dats);
			$("#subcategoria"+b).html("<option value=''>Seleccionar subcategoría</option>");
			$.get(dominio+'lib/ajax_hlo.php',{"cod":"subcategoria", "categoria":dats},function(response){
				var itm = JSON.parse(response);
				$.each(itm,function(p,a){	console.log(a);
					$("#subcategoria"+b).append("<option value='"+a.id_matrix+"'>"+a.nombre_matrix+"</option>");
					})
				})
		}


		$(function(){

			var data = { items:[]};

			var datacontacto = { items:[]};

			function compro_email(dato)
			{
			    expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			    if (!expr.test(dato))
			    {
			       return false;
			    }
			    else {  return true; }

			}

			function compro_phone(dato)
			{
			    expr = /^([\+][0-9]{1,3}([ \.\-])?)?([\(][0-9]{1,6}[\)])?([0-9 \.\-]{1,32})(([A-Za-z \:]{1,11})?[0-9]{1,4}?)$/;
			    if (!expr.test(dato))
			    {
			       return false;
			    }
			    else {  return true; }

			}

			function compro_url(dato)
			{
				expr = /^(http|https|)\:\/\/[a-z0-9\.-]+\.[a-z]{2,4}/gi;
				if (!expr.test(dato))
			    {
			       return false;
			    }
			    else {  return true; }
			}


			function contrasegura(dato)
			{
					// set password variable
			        var pswd = dato;
			        //validate the length
			        if ( pswd.length < 8 ) {
			            return false;
			        }
			        //validate letter
			        if (pswd.match(/[A-z]/) ) {

			        } else {

			            return false;

			        }



			        //validate capital letter

			        if (pswd.match(/[A-Z]/) ) {



			        } else {

			           return false;

			        }



			        //validate number

			        if ( pswd.match(/\d/) ) {

			            return true;

			        } else {

			           return false;

			        }

			}

			function isNumberKey(evt)

			{

				var charCode = (evt.which) ? evt.which : evt.keyCode;
			console.log(charCode);
				// Added to allow decimal, period, or delete

				if (charCode == 110 || charCode == 190 || charCode == 46)

					return true;

				if (charCode > 31 && (charCode < 48 || charCode > 57)){
					return false;
				}
			}

			function otronumber(evt){
				var txt = evt;

				if (!/^([0-9])*$/.test(txt)) {
					console.log(txt);
					return false;
				}
			}

			function comprobar_doc(val)
			{
				switch(val.substring(val.lastIndexOf('.')+1).toLowerCase())
				{ case 'gif': case 'jpg': case 'png':
				return true;
				break;
				default:
				return false;
				break;
				}
			}




			function ValidarPestana(divname)
			{
				var ne =0;
				var div = document.getElementById(divname);
				$(div).find('.required')
				        .each(function() {
				                 txt = $(this).val();
								tipo = $(this).attr("rel");
								if (txt=="")
								{
									ne++;
									$(this).focus().after("<span class='error-site'>"+FIELD_REQUIRED+"</span>");
									setTimeout(function(){
										$("#form-proyecto .error-site").hide();
									},3000);
									return false;
								}

								else if(tipo=="email")
								{
									if (!compro_email(txt))
									{
										ne++;
										$(this).focus().after("<span class='error-site'>"+INVALID_EMAIL_ADDRESS+"</span>");
										setTimeout(function(){
											$(form+" .error-site").hide();$(this).hide();
										},3000);
										return false;
									}
								}

								else if(tipo=="phone")
								{
									if (!compro_phone(txt))
									{
										ne++;
										$(this).focus().after("<span class='error-site'>"+INVALID_PHONE_NUMBER+"</span>");
										setTimeout(function(){
											$(form+" .error-site").hide();$(this).hide();
										},3000);
										return false;
									}
								}

								else if(tipo=="password")
								{
									if (!contrasegura(txt))
									{
										ne++;
										$(this).focus().after("<span class='error-site'>"+VALID_PSW+"</span>");
										setTimeout(function(){
											$(form+" .error-site").hide();
										},3000);
										return false;
									}
								}

								else if(tipo=="textarea")
								{
									if (txt.length<20)
									{
										ne++;
										$(this).focus().after("<span class='error-site'>"+CHARACTERS_MIN+"</span>");
										setTimeout(function(){
											$(form+" .error-site").hide();
										},3000);
										return false;
									}
								}

								else if(tipo=="url")
								{
									if (!compro_url(txt)){
									ne++;
									$(this).focus().after("<span class='error-site'>"+INVALID_URL+"</span>");
									setTimeout(function(){
										$(form+" .error-site").hide();
									},3000);
									return false;
								}
								}

								else if(tipo=="documento")
								{
									if(!comprobar_doc(txt))
									{
										ne++;
										$(this).focus().after("<span class='error-site'>"+GIF_JPG_PNG_FORMAT+"</span>");
										setTimeout(function(){
											$(form+" .error-site").hide();
										},3000);
										return false;
									}
								}




				  });

				if (ne==0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}

			$(".siguiente").click(function(){

				divname="";
				var num = $(this).attr("rel");
				if (num==2)
					divname="cont1";

				if (num==3)
					divname="cont2";

				if (num==4)
					divname="cont3";

				if (num==5)
					divname="cont4";

				if (num==6)
					divname="cont5";

				if (ValidarPestana(divname)){


		 		   var nums = num-1;

	 		   	   // if (!vacios("#form-proyecto #cont"+nums)){ return false;}
	 			   var posig = $("#conproghtyrgha").position();
		 		   $('html,body').animate({scrollTop: posig.top}, 1000);
	 		   	   $("#spa"+num).addClass("active");
				   $('#form-proyecto #cont'+nums).hide();
				   $('#form-proyecto #cont'+num).show();

				}



			})

			$(".anterior").click(function(){
				var num = $(this).attr("rel");
				var nums = parseInt(num)+1;
				var posig = $("#conproghtyrgha").position();
		 		$('html,body').animate({scrollTop: posig.top}, 1000);
			 	$("#spa"+nums).removeClass("active");
			 	$("#spa"+num).addClass("active");
				$('#form-proyecto #cont'+nums).hide();
				$('#form-proyecto #cont'+num).show();
			})

			$("#abrirpopup").click(function(){
				 $('#basic').popup('show')
			})
			$("#abrirdivequipo").click(function(){
				 $('#divequipo').popup('show')
			})


			 $('#saverecompensa').click(function() {
                 nombre = $("#nombre_recompensa").val();
                 descripcion = $("#descripcion_recompensa").val();
                 monto = $("#valor_recompensa").val();
                 plazo = $("#plazo_recompensa").val();
                 envio = $("#envio_recompensa").val();
                 numero = $("#numero_recompensa").val();//
     			 $('#tablarecompensa tbody').append('<tr class="child"><td>'+nombre+'</td><td>'+descripcion+'</td><td>'+monto+'</td><td>'+plazo+'</td><td>'+envio+'</td><td>'+numero+'</td><td><a class="remove  btn" id="remove"><i class="material-icons">clear</i></a></td></tr>');
    		     // Falta guardar las variables en un array para enviar por POST al enviarse al servidor

     			 $("#nombre_recompensa").val("");
                 $("#descripcion_recompensa").val("");
                 $("#valor_recompensa").val("");
                 $("#plazo_recompensa").val("");
                 $("#envio_recompensa").val("");
                 $("#numero_recompensa").val("");


				 var reg = {recompensa: nombre, descripcion: descripcion, monto_recompensa: monto,fecha_recompensa:plazo,envio_recompensa:envio,numero_recompensa:numero}
				 data.items.push(reg);

				 $("#hdrecompensas").val(JSON.stringify(data));
     			 $('#basic').popup('hide')
    		 });


			$('#savecontacto').click(function() {

                 correo = $("#correo_contacto_proyecto").val();
                 nombre = $("#nombre_contacto").val();
                 cedula = $("#cedula_contacto").val();
                 fijo = $("#fijo_contacto").val();
                 celular = $("#celular_contacto").val();
                 fnacimiento = $("#nacimiento_contacto").val();//
                 pais = $("#pais_contacto_proyectopopup").val();
                 paistext = $("#pais_contacto_proyectopopup :selected").text();//$("#pais_contacto_proyectopopup").val();
                 //$("#myselect :selected").text();
                 departamento = $("#departamento22").val();
                 departamentotext = $("#departamento22 :selected").text();
                 ciudad = $("#ciudad22").val();
                 ciudadtext = $("#ciudad22 :selected").text();
                 postal =$("#postal_contacto").val();
                 legal = $("#legal_contacto").val();

                 tiponegocio = $("#tipo_negocio").val();
                 nit = $("#nit_contacto").val();



     			 $('#tablacontacto tbody').append('<tr class="child"><td>'+nombre+'</td><td>'+cedula+'</td><td>'+celular+'</td><td>'+fnacimiento+'</td><td>'+paistext+'</td><td>'+ciudadtext+'</td><td><a class="remove  btn" id="removecontacto"><i class="material-icons">clear</i></a></td></tr>');
    		     // Falta guardar las variables en un array para enviar por POST al enviarse al servidor

     			 $("#correo_contacto_proyecto").val("");
                 $("#nombre_contacto").val("");
                 $("#cedula_contacto").val("");
                 $("#fijo_contacto").val("");
                 $("#celular_contacto").val("");
                 $("#nacimiento_contacto").val("");//
                 $("#pais_contacto_proyectopopup").val("");
                 $("#departamento22").val("");
                 $("#ciudad22").val("");
                 $("#postal_contacto").val("");
                 $("#legal_contacto").val("");

                 $("#tipo_negocio").val("");
                 $("#nit_contacto").val("");


				 var reg = {correo_contacto: correo, nombre_contacto: nombre, cedula_contacto: cedula,fijo_contacto:fijo,celular_contacto:celular,nacimiento_contacto:fnacimiento,pais_contacto:pais,departamento:departamento,ciudad:ciudad,postal_contacto:postal,legal_contacto:legal,tipo_negocio:tiponegocio,nit_contacto:nit}
				 datacontacto.items.push(reg);

				 $("#hdequipo").val(JSON.stringify(datacontacto));


     			 $('#divequipo').popup('hide')
    		 });






			$('#tablarecompensa').on('click', '#remove', function(){
					$(this).parent().parent().remove();
			});

			 $('.datepicker').pickadate({
			    selectMonths: true, // Creates a dropdown to control month
			    selectYears: 15, // Creates a dropdown of 15 years to control year
			    format: 'yyyy-mm-dd'
			  });

		})

			    if(window.FormData){
			        formdata = new FormData();
			    }

			    //evento añadir imagen
			    function handleFileSelect(evt) {
			        var files = evt.target.files; // FileList object
			        $(".cargaimagen").html("");
			        $(".txtcargimj").html("Cargando vista previa...");
			        // Loop through the FileList and render image files as thumbnails.

			        for (var i = 0, f; f = files[i]; i++) {
			          if( (f.type.toLowerCase() == "image/JPEG") || (f.type.toLowerCase() == "image/jpeg") || (f.type.toLowerCase() == "image/jpg") || (f.type.toLowerCase() == "image/JPG") || (f.type.toLowerCase() == "image/png") || (f.type.toLowerCase() == "image/PNG") || (f.type.toLowerCase() == "image/gif") || (f.type.toLowerCase() == "image/GIF") ) {

			                //si la imagen es mayor a 1024 kb
			                console.log(f.size);
			                if((f.size > 3048576 )){

			                    alert("la Imágen "+f.name+" excede el peso permitido ("+Math.round((f.size)/1024)+" Kb), el peso máximo permitido es de 1024 Kb (1 Mb)");
			                    return false;
			                }
			            }
			            else{
			                alert("Solo se permiten subir imágenes en formato JPG,PNG");
			                return false;
			            }



			          var reader = new FileReader();

			          // Closure to capture the file information.
			          reader.onload = (function(theFile) {
			            formdata.append('imagen', theFile);
			            return function(e) {
			              imagen = e.target.result;
			              $(".txtcargimj").html("");
			              $(".cargaimagen").append("<div class='thumbnail recuadroImgCategoria'>"+
			                                    	"<img class='img-responsive' src='"+e.target.result+"'/>"+
			                                    	"<div class='deleteUrl' onclick='return cerrarImagen()'></div>"+
			                                    escape(theFile.name)+
			                                "</div>");
			              $("#imagenVistaPrevia").attr("src",e.target.result);

			            };
			          })(f);

			          // Read in the image file as a data URL.
			          reader.readAsDataURL(f);
			        }
			    }

	</script>

	</body>
</html>

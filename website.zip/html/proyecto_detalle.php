<?php
	include "include/includes.php";
	if (isset($_GET['id_proyecto'])) {
		$id_proyecto= $_GET['id_proyecto'];
		$db->select("proyecto  INNER JOIN categoria  on proyecto.categoria_proyecto = categoria.id_categoria ","*","where id_proyecto = $id_proyecto");
		$datos = $db->fetch_array();
		$db->select("imagenes_proyecto","*","where id_proyecto = $id_proyecto limit 1");
		$result = $db->fetch_array();

	}else{
		header('location:http://coremas.com.co/error404.php');
	}
	$totalFecha = totalFechas($datos['fecha_publicacion'], $datos['plazo_financiacion_proyecto']);
	$diasfaltan = restaFechas($datos['plazo_financiacion_proyecto'],date("Y-m-d"));

	if($diasfaltan < 0){ $diasfaltan = 0; }
	$procfechdi = ($diasfaltan/$totalFecha) * 100;
	$procfechdi = round($procfechdi);

	?>
</head>

<body>
	<?php include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container">
			 <h1>Proyecto</h1>
		</div>
	</div>
	<div class="detalleproyecto">
		<div class="container">
			<div class="row">
				<div class="col s12 m12 l8">
					<div class="proyecto-main-info">
						<div class="conimg">
							<?php
								$ruta_img = "";
								if($result['ruta_imagen']!=""){
									$ruta_img = $result['ruta_imagen'];
								}else{
									$ruta_img = "images/logo.png";
								}

							?>
							<a href="<?php echo $datos['video_proyecto'];?>" rel="prettyPhoto">
								<div class="cont-img-main" style="background-image: url('<?php echo $dominio.$ruta_img; ?>'); background-repeat: no-repeat; background-position: center; background-size: contain; height: 500px;">
								</div>
							</a>

							<div class="rep">
								<a href="<?php echo $datos['video_proyecto'];?>" rel="prettyPhoto"><img src="<?php echo $dominio ?>images/repr.png" alt="" title=""></a>
							</div>

							<div class="cont">
								<img src="<?php echo $dominio ?>images/plusico.png" alt="" title="" rel="<?php echo $datos['id_proyecto'] ?>" <?php  if ($_SESSION['id_core'] != ""){ ?> class="btonmeguta" <?php } ?> >

								<!--cuantos likes he recibido-->
								<?php
									$db->select("relacion","cantidad","where id_tipo=104 and de='$datos[id_proyecto]'");
									// echo $db->last_query();
									$canti = $db->num_rows();
								?>
								<span><?php echo $canti;?></span>
							</div>
						</div>
						<div class="conmiga">
							<img src="<?php echo $dominio ?>images/icomap1.png" alt="" title=""> <b>

							<?php
								$city=$datos['ciudad_proyecto'];
								$dep = $datos['departamento_proyecto'];
								$db->select("ciudad,departamento","*"," where ciudad.id_ciudad=$city");
								$row = $db->fetch_array();
								echo $row['nombre_ciudad'].", ".$row['nombre_departamento'];
							?></b>
							<span><?php echo $datos['nombre_categoria']?></span>
						</div>
						<br>
						<ul class="tabs">
					        <li class="tab col s3"><a class="active" href="#descripcion">DESCRIPCIÓN</a></li>
					        <li class="tab col s3"><a href="#comentario">COMENTARIOS</a></li>
					        <li class="tab col s3"><a href="#patrocinadores">PATROCINADORES</a></li>
					    </ul>
					    <br>
					    <div id="descripcion" class="contdescrip">
					    	<p><?php echo $datos['descripcion_proyecto'];?></p>
								<br><br><br>
					    	<img src="<?php echo $dominio ?>images/logo.png" alt="" title="">
					    	<p></p>
					    	<p></p>
					    </div>
					    <div id="comentario" class="concomentario">
					    	<?php
					    		#si hay session muestra el form
					    		if(isset($_SESSION['id_core']) && $_SESSION['id_core'] != ""){
					    	?>
								    <form class="comentario" action="" method="" rel="<?php echo $datos['id_proyecto'] ?>">
								    	<textarea name="comentario" height="100" ></textarea>
								    	<button class="btn">Enviar</button>
								    </form>
					   		<?php
					   			}else{
					   				#mostrar mensaje que diga debe iniciar sesion
			   				?>
			   						<h5>Es necesario registrarse para comentar</h5>
			   				<?php
					   			}
					   			$db->select("comentario as c, registrado as r","*","where c.id_registrado=r.id_registrado and c.estado_comentario=1 and c.id_maestra='$datos[id_proyecto]'");
					   			while ($datosco = $db->fetch_array()) {
					   				$fgrt = explode(" ", $datosco['fecha_comentario']);
					   				$fecha = explode("-",$fgrt[0]);

					   		?>
					    	<div class="item">
					    		<h3><?php echo $datosco['nombre_registrado'] ?><span><?php echo $fecha[2]." ".strtoupper(substr(nombremes($fecha[1]),0,3))." ".$fecha[0] ?></span></h3>
					    		<p><?php echo $datosco['comentario'] ?></p>
					    		<!-- <a href="">Ver respuestas(5)</a> -->
					    	</div>
					    	<?php } ?>
					    </div>
					    <?php
					    	$db->select("donaciones","*"," where proyecto = $_GET[id_proyecto] && estado = 1 order by fecha_donacion");
					    	//echo $db->last_query();
					    ?>
					    <div id="patrocinadores" class="conpatrocinadores">
						    <?php
						    	$ttdonacion = 0;
						    	$db->select("donaciones as d, registrado as r, proyecto as p","d.*, r.*, p.valor_recompensa1, p.valor_recompensa2, p.valor_recompensa3, r.nombre_registrado","where p.id_proyecto=d.proyecto and r.id_registrado=d.usuario and d.proyecto=$id_proyecto ");
									$recoda = array();
						    	while ($datosds = $db->fetch_array()) {
						    		$recoda[] = $datosds;
						    	}
						    	foreach($recoda as $datosds){
						    		$ttdonacion += $datosds[valor];
						    		$dona = $datosds[valor];
						    		if ($datosds[recompensa]>0) {
						    			$numd = $datosds[recompensa];
						    			$dona = $datosds['valor_recompensa'.$numd];
						    			$ttdonacion+=$dona;
						    		}
					    	?>
					    	<div class="item">
					    	<!-- <?php print_r($datosds); ?> -->
					    		<img src="<?php echo $dominio ?>images/imguser.png" alt="" title="">
					    		<h4>
					    			<b><?php echo $datosds['nombre_registrado'] ?></b>
					    			<!-- Hace tantas horas o días -->
					    			<?php
					    				$numfd = restaFechas($datosds['fecha_donacion'], date("Y-m-d"));
					    				$txt = "Hace ".$numfd." Día(s)";
					    				if ($numfd<=0) {
					    				 	$txt = "Hace menos de 24 horas";
					    				 }

					    				echo $txt;
					    			?>
					    			<span>$<?php echo number_format($dona) ?></span>
					    		</h4>
					    	</div>
					    	<?php } ?>
					    </div>
				    </div>
				</div>
				<div class="col s12 m12 l4 conizq">
					<h2><?php echo $datos['nombre_proyecto'];?></h2>
					<p>Fecha de publicación <span><?php

									$fgrt1 = explode(" ", $datos['fecha_publicacion']);
					   				$fecha1 = explode("-",$fgrt1[0]);

 					   				echo $fecha1[2]." ".strtoupper(substr(nombremes($fecha1[1]),0,3))." ".$fecha1[0];?></span></p>
					<div class="contpre">
						<?php
							$porcen = round(($ttdonacion *100)/ $datos['valor_proyecto']);
							$maspor = $porcen;
							if($porcen > 100) {
		    					$porcen = 100;
		    					$maspor = 100;
		    				}
						?>
						<div class="c100 p<?php echo $porcen; ?>">
		                    <span><?php echo $maspor ?>%</span>
		                    <div class="slice">
		                        <div class="bar"></div>
		                        <div class="fill"></div>
		                    </div>
		                </div>
		                <h5><?php echo "$ ". number_format($ttdonacion,0,",","." ); ?></h5>
		                <p>Recaudados de<br> <?php echo "$ ". number_format($datos['valor_proyecto'],0,",","." ); ?></p>
					</div>
					<?php
						$restan = round(100 - $porcen);
					?>
					<div class="contpe">
						<div class="c100 p<?php echo $procfechdi ?> small">
		                    <span style="line-height: 18px; padding-top: 22px;"><?php echo $diasfaltan ?><br>Días</span>
		                    <div class="slice">
		                        <div class="bar"></div>
		                        <div class="fill"></div>
		                    </div>
		                </div>
		                <h5>Restantes</h5>
					</div>
					<h3 class="conus">
						<img src="<?php echo $dominio ?>images/imguser.png" alt="" title="">
						<?php echo substr($datos['nombre_registrado'],0,25); ?>
					</h3>
					<div class="compart">
						Compartir <?php include "include/compartir.php"; ?>
					</div>
					<br><br>
					<div class="pagos">
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="VVVLE5CAXW5AE">
							<input type="image" width="220px" height="50px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/PayPal_2014_logo.svg/1000px-PayPal_2014_logo.svg.png" border="0" name="submit" alt="PayPal, la forma rápida y segura de pagar en Internet.">
							<img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1">
						</form>

						<!--form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="DSZT97PJWXARW">
							<input type="hidden" name="custom[]" value="<?php echo $id_proyecto; ?>"/>
							<input type="hidden" name="custom[]" value="<?php echo $datos['nombre_proyecto'];  ?>"/>
							<input type="hidden" name="custom[]" value="<?php echo $datosco['nombre_registrado'];  ?>"/>


							<input type="image" width="220px" height="50px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/PayPal_2014_logo.svg/1000px-PayPal_2014_logo.svg.png" border="0" name="submit" alt="PayPal, la forma rápida y segura de pagar en Internet.">
							<img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1">
						</form-->


					</div>
					<br>
					<?php
						if($_SESSION['id_core']==""){ ?>
			        		<a href="#modalsesion" class="modal-trigger link">PATROCINAR</a>
			      		<?php } else{ ?>
			      			<a href="#modalformproyecto" id="donanormal" class="modal-trigger link">PATROCINAR</a>
			      		<?php } ?>
					<br><br><br>

					<div class="conrecome">
						<h3>RECOMPENSAS</h3>
						<?php
							$cpadre = array();
	 						$db->select("proyectoxrecompensa", "*", " where idproyecto=".$_GET['id_proyecto']." ");

	 						while ($row = $db->fetch_array()) {
						   		$cpadre[]=$row;
					  	 	}
						    foreach ($cpadre as $row) {
								//for ($i=1; $i < 4 ; $i++) {
								//	if ($datos['nombre_recompensa'.$i.''] != "") {
						?>
								<h5> <?php echo " $". number_format($row["monto_recompensa"],0,",","." )." ". $row["recompensa"];?></h5>
								<div class="cont recompensa" rel="$<?php echo number_format($row["monto_recompensa"],0,",","." ) ?>" data-nombre="<?php echo $row["recompensa"]; ?>" data-id="<?php echo $row["id"] ?>" >
									<p><?php echo $row["descripcion"];?> </p>
									<ul>
										<li>- Fecha de entrega: <?php
										$date = new DateTime($row["fecha_recompensa"]);
										$fecha_recompensa= $date->format('d/m/Y');

										echo $fecha_recompensa; ?></li>
									</ul>
								</div>
					<?php
							}
						//}
					?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include "include/suscribir.php"; ?>
	<?php include "include/footer.php"; ?>
 		  <!-- Modal Structure -->
		  <div id="modalformproyecto" class="modal">
		    <div class="modal-content">
		      <h4>Formulario para patrocinador</h4>
		       <form action="" method="" id="formulariodona">
		       		<input type="hidden" name="tipo" value="106" >
		       		<!-- <div class="input-field">
		       			<p>Tipo de donación</p>
		       			<select class="required" id="seleTipoDona" name="tipo">
		       				<option value="">Seleccionar</option>
		       				<?php
		       					$db->select("tipo","*","where idr=40 order by nombre_tipo asc");
		       					while ($datos = $db->fetch_array()) {
		       				?>
		       					<option value="<?php echo $datos['id_tipo'] ?>"><?php echo $datos['nombre_tipo'] ?></option>
		       				<?php
		       					}
		       				?>
		       			</select>
		       		</div> -->

		       		<!-- Si es insumos -->
		       		<!-- <div class="divDonaTip input-field" id="inpuins" style="display: none;">
		       			<textarea placeholder="Explicación de insumo" class=" verf materialize-textarea" name="txtInsumo" ></textarea>
		       			<input type="number" placeholder="Valor del insumo" class="verf" name="valInsum">
		       		</div> -->

		       		<!-- Trabajo -->
		       		<!-- <div class="divDonaTip input-field" id="inptrba" style="display: none;">
		       			<textarea placeholder="Descripción del trabajo" class="verf materialize-textarea" name="txtTrab" ></textarea>
		       			<input type="number" placeholder="Valor del trabajo" class="verf" name="valiTrabj">
		       		</div> -->

		       		<!-- Donación -->
		       		<div class="divDonaTip input-field" id="inputdona"  >
		       			<input type="number" placeholder="Valor a donar en dolares" class="verf" name="valDonac">
		       			<p>Gracias por apoyarnos.</p>
		       			<br><br>
		       		</div>
		       		<div id="inputRecompe">
		       			<h3 id="nombrerecompensa"></h3>
		       			<h4 id="preciorecom"></h4>
		       			<input type="hidden" name="idreco" id="idreco">
		       		</div>
		       		<input type="hidden" name="idPro" value="<?php echo $id_proyecto ?>" >
		       		<input type="hidden" name="cod" value="metDonaciones" >
		       		<button class="btn">Enviar donación</button>
		       		<a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cancelar</a>
		       </form>
		    </div>

		  </div>
		  <script type="text/javascript">
		  	$(function(){
		  		$(".comentario").submit(function(){
		  			var com = $(this).find("textarea[name=comentario]").val();
		  			$(this).find("textarea[name=comentario]").focus();
		  			var t = $(this);
		  			var id = $(this).attr("rel");
		  			if (com!=""){
		  				$.post("<?php echo $dominio ?>lib/ajax_hlo.php",{"cod":"comentarios","comentario":com,"id":id},function(data){
		  					t.find("textarea[name=comentario]").val("");
		  					swal({
			                  title: "Excelente",
			                  text: "El comentario se envio correctamente!",
			                  type: "success",
			                  closeOnConfirm: false
			                },function(){
			                  location.reload();
			                });
		  				})
		  			}
		  			return false;
		  		})
		  		$(".recompensa").click(function(){
		  			$(".divDonaTip").find(".verf").removeClass("required");
		  			var idr = $(this).attr("rel");
		  			var reconom = $(this).attr("data-nombre");
		  			var numid = $(this).attr("data-id");
		  			$("#inputdona").hide();
		  			$("#nombrerecompensa").html(reconom);
		  			$("#preciorecom").html(idr);
		  			$("#idreco").val(numid);
		  			$("#modalformproyecto").openModal();
		  		})
		  		$("#donanormal").click(function(){
		  			$("#inputdona").show();
		  			$("#inputdona").find(".verf").addClass("required");
		  		})
		  		$("#seleTipoDona").change(function(){
		  			var num = $(this).val();
		  			$(".divDonaTip").hide();
		  			$(".divDonaTip").find(".verf").removeClass("required");
		  			if (num==105) {
		  				$("#inpuins").show();
		  				$("#inpuins").find(".verf").addClass("required");
		  			}
		  			else if (num==107) {
		  				$("#inptrba").show();
		  				$("#inptrba").find(".verf").addClass("required");
		  			}
		  			else if (num==106) {
		  				$("#inputdona").show();
		  				$("#inputdona").find(".verf").addClass("required");
		  			}
		  		})

		  		$("#formulariodona").submit(function(){
		  			if (!vacios("#formulariodona")){
		  				return false;
		  			}

		            $.ajax({
		            data: $(this).serialize(),
		                  url:   dominio+'lib/ajax_hlo.php',
		                  type:  'POST',
		                  beforeSend: function ()
		                  {

		                  },
		                  success:  function (response) {
		                    swal({
			                  title: "Correcto",
			                  text: "Su donación se a realizado correctamente, uno de nuestros administradores la validara para poder colocarlo en la lista de dornadores.",
			                  type: "success",
			                  closeOnConfirm: false
			                },function(){
			                  location.reload();
			                });
		                  }
		              });
		            return false;
		  		})

		  	})
		  </script>
</body>
</html>

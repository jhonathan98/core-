<?php
$string  = '{"items":[{"correo_contacto":"rtqw","nombre_contacto":"tqtw","cedula_contacto":"23532","fijo_contacto":"5325","celular_contacto":"5325","nacimiento_contacto":"2017-09-05","pais_contacto":"ARG","departamento":"56","ciudad":"6512","postal_contacto":"532532","legal_contacto":"5325","tipo_negocio":"53252","nit_contacto":"532532","iva_contacto":"12"},{"correo_contacto":"rdasffsafafa","nombre_contacto":"fsafaf","cedula_contacto":"214","fijo_contacto":"424","celular_contacto":"412412","nacimiento_contacto":"2017-09-28","pais_contacto":"AND","departamento":"1434","ciudad":"4599","postal_contacto":"4214","legal_contacto":"42412","tipo_negocio":"4214","nit_contacto":"42141","iva_contacto":"4214"}]}';
//print_r((array)json_decode($string));
$user = (array)json_decode($string);
//echo $user;
foreach($user['items'] as $key=>$val){ 

	 echo $val->correo_contacto;
}	



foreach($user as $value){
  echo $value->items["nombre"];
}



//echo $user['items']; 
foreach ($user->items as $key => $value) {
    echo $value["nombre"] . ", " . $value["descripcion"] . "<br>";
 }

?>


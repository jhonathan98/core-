<?php
include "include/includes.php";

if ($_POST) {
$db->select("proyectosinterminar","id_registrado","where id_registrado = '".$_SESSION['id_core']."' ");
$total = $db->num_rows();


$fecha = date("Y-m-d");
$datos = array(
  //cont1
  "id_registrado"         		=>$_SESSION['id_core'],
  "nombre_proyecto"				=>$_POST['nombre_proyecto'],
  "categoria_proyecto"			=>$_POST['categoria_proyecto1'],
  "descripcion_proyecto"			=>$_POST['descripcion_proyecto'],
  "fase_proyecto"					=>$_POST['fase_proyecto'],
  "pais_proyecto"					=>$_POST['pais_proyecto'],
  "departamento_proyecto"			=>$_POST['departamento_proyecto'],
  "ciudad_proyecto"				=>$_POST['ciudad_proyecto'],

  //cont2
  "cliente_proyecto"            	=>$_POST['cliente_proyecto'],
  "problema_proyecto"				=>$_POST['problema_proyecto'],
  "solucion_proyecto"				=>$_POST['solucion_proyecto'],
  "ventaja_proyecto"				=>$_POST['ventaja_proyecto'],
  "propuesta_proyecto"			=>$_POST['propuesta_proyecto'],
  "fuente_proyecto" 				=>$_POST['fuente_proyecto'],

  //cont3
  "costos_proyecto"				=>$_POST['costos_proyecto'],
  "valor_proyecto"				=>$_POST['valor_proyecto'],
  "plazo_financiacion_proyecto"	=>$_POST['plazo_financiacion_proyecto'],
  "nombre_recompensa1"			=>$_POST['nombre_recompensa'],
  "descripcion_recompensa1"		=>$_POST['descripcion_recompensa'],
  "valor_recompensa1"				=>$_POST['valor_recompensa'],
  "plazo_recompensa1"				=>$_POST['plazo_recompensa'],
  "envio_recompensa1"				=>$_POST['envio_recompensa'],
  "numero_recompensa1"			=>$_POST['numero_recompensa'],

  "nombre_recompensa2"			=>$_POST['nombre_recompensa2'],
  "descripcion_recompensa2"		=>$_POST['descripcion_recompensa2'],
  "valor_recompensa2"				=>$_POST['valor_recompensa2'],
  "plazo_recompensa2"				=>$_POST['plazo_recompensa2'],
  "envio_recompensa2"				=>$_POST['envio_recompensa2'],
  "numero_recompensa2"			=>$_POST['numero_recompensa2'],

  "nombre_recompensa3"			=>$_POST['nombre_recompensa3'],
  "descripcion_recompensa3"		=>$_POST['descripcion_recompensa3'],
  "valor_recompensa3"				=>$_POST['valor_recompensa3'],
  "plazo_recompensa3"				=>$_POST['plazo_recompensa3'],
  "envio_recompensa3"				=>$_POST['envio_recompensa3'],
  "numero_recompensa3"			=>$_POST['numero_recompensa3'],

  //cont4
  "descripcion_equipo"		=>$_POST['descripcion_equipo'],


  //cont5
  "video_proyecto"				=>$_POST['video_proyecto'],
  "descripcion_extra"				=>$_POST['descripcion_extra'],
  //"documento_extra"				=>$_FILES[documento_extra],
  "fecha_publicacion"				=>$fecha,



);
if($total == 0){

  $db->insert("proyectosinterminar",$datos);
  //$valor = $db->last_query();
  $idp = $db->insert_id;



  $string = $_POST[hdequipo];
  $user = (array)json_decode($string);
  //echo $user;

  $string = $_POST[hdrecompensas];
  $user = (array)json_decode($string);
  //echo $user;
  foreach($user['items'] as $key=>$val){
     $datosrecompensa = array(

     "recompensa"           => $val->recompensa,
     "descripcion"          => $val->descripcion,
     "monto_recompensa"     => $val->monto_recompensa,
     "fecha_recompensa"     => $val->fecha_recompensa,
     "envio_recompensa"     => $val->envio_recompensa, //
     "num_recompensa"    => $val->numero_recompensa,
     "idproyecto"           => $idp
     );

     $db->insert("proyectoxrecompensasinterminar",$datosrecompensa);
  }

  //Nombre archivo
  $archivo = $_FILES["documento_extra"]['name'];

  //Extencion de archivo
  $datos 	= explode(".", $archivo);
  $ext 	= end($datos);
  $tamano = $_FILES["documento_extra"]['size'];
  $tipo 	= $_FILES["documento_extra"]['type'];

  if ($archivo != "") {
    //nombre archivo personalizado
    $nombre_ar 	= $idp."_documento.".$ext;
    $destino 	= "proyectos/docs/".$nombre_ar;
    //Seguarda el archivo en la ruta y nombre especificado
    if (copy($_FILES['documento_extra']['tmp_name'],$destino))
    {
      $respuestareg = 1;
      $db->consulta_s("UPDATE proyectosinterminar set documento_extra='$nombre_ar' where id_proyecto='$idp'");
      //$db->UPDATE("proyecto", "set documento_extra=$nombre_ar"," where id_proyecto=$idp");
    }
  }
  /*
  // carga imagenes
  $imgs = $_FILES['galeria_proyecto']['name'];
  $imgnum = count($imgs);

  if ($imgnum>0) {
    $imgs = $_FILES['galeria_proyecto'];

     for ($i=0; $i < $imgnum; $i++) {

      $archivo = $_FILES["galeria_proyecto"]['name'][$i];

      //Extensión de archivo
      $datos 	= explode(".", $archivo);
      $ext 	= end($datos);


      $tamano = $_FILES["galeria_proyecto"]['size'][$i];
      $tipo 	= $_FILES["galeria_proyecto"]['type'][$i];

      if ($archivo != "") {
        //nombre archivo personalizado
        $nombre_ar = $idp."_imagenes.".$ext;
        //Ruta donde se guarda el archivo
        $destino = "proyectos/img/".$nombre_ar;
        //Seguarda el archivo en la ruta y nombre especificado
        if (copy($_FILES['galeria_proyecto']['tmp_name'][$i],$destino)) {
          $respuestareg = 1;
          $vector = array(
            "id_proyecto"	=>$idp,
            "ruta_imagen"	=>$destino
         );
        $db->insert("imagenes_proyecto",$vector);

        }
      }
    }
  }else{
    echo "error";
  }*/
}else{
  $db->select("proyectosinterminar inner join proyectoxrecompensasinterminar","proyectoxrecompensasinterminar.idproyecto","on proyectosinterminar.id_registrado = '".$_SESSION['id_core']."' ");
  $resultado=$db->fetch_array();
  $idPST=$resultado["idproyecto"];
  echo "imprimir   ".$idPST;
  var_dump($resultado);
  $db->update("proyectosinterminar",$datos,"where id_registrado = '".$_SESSION['id_core']."' ");



  $string = $_POST[hdequipo];
  $user = (array)json_decode($string);
  //echo $user;

  $string = $_POST[hdrecompensas];
  $user = (array)json_decode($string);
  //echo $user;
  foreach($user['items'] as $key=>$val){
     $datosrecompensa = array(

     "recompensa"           => $val->recompensa,
     "descripcion"          => $val->descripcion,
     "monto_recompensa"     => $val->monto_recompensa,
     "fecha_recompensa"     => $val->fecha_recompensa,
     "envio_recompensa"     => $val->envio_recompensa, //
     "num_recompensa"    => $val->numero_recompensa,
     "idproyecto"           => $idPST
     );

     $db->update("proyectoxrecompensasinterminar",$datosrecompensa,"where idproyecto ='".$idPST."'");
     $db->last_query();
  }

  //Nombre archivo
  $archivo = $_FILES["documento_extra"]['name'];

  //Extencion de archivo
  $datos 	= explode(".", $archivo);
  $ext 	= end($datos);
  $tamano = $_FILES["documento_extra"]['size'];
  $tipo 	= $_FILES["documento_extra"]['type'];

  if ($archivo != "") {
    //nombre archivo personalizado
    $nombre_ar 	= $idp."_documento.".$ext;
    $destino 	= "proyectos/docs/".$nombre_ar;
    //Seguarda el archivo en la ruta y nombre especificado
    if (copy($_FILES['documento_extra']['tmp_name'],$destino))
    {
      $respuestareg = 1;
      $db->consulta_s("UPDATE proyectosinterminar set documento_extra='$nombre_ar' where id_proyecto='$idp'");
      //$db->UPDATE("proyecto", "set documento_extra=$nombre_ar"," where id_proyecto=$idp");
    }
  }
}
}

 ?>

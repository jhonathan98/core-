<div class="header">
		<div class="container">
			<nav>
		    <div class="nav-wrapper">
		      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
		      <a href="#" class="brand-logo"><img src="images/logo.png" alt="" title=""></a>
		      <ul id="nav-mobile" class="right hide-on-med-and-down">
		        <li><a href=""><span>INICIAR UN PROYECTO</span></a></li>
		        <li><a href="">Explorar Proyectos</a></li>
		        <li><a href="#modalsesion" class="modal-trigger">Acceso</a></li>
		        <li><a href="#modalsesion" class="modal-trigger">Registro</a></li>
		        <li>
		        	<form>
		        		<input type="text" placeholder="Buscar Proyectos" >
		        		<button><img src="images/lupa.png" alt="" title=""></button>
		        	</form>
		        </li>
		      </ul>

		      <ul class="side-nav" id="mobile-demo">
		        <li><a href=""><span>INICIAR UN PROYECTO</span></a></li>
		        <li><a href="">Explorar Proyectos</a></li>
		        <li><a href="#modalsesion" class="modal-trigger">Acceso</a></li>
		        <li><a href="#modalsesion" class="modal-trigger">Registro</a></li>
		        <li>
		        	<form>
		        		<input type="text" placeholder="Buscar Proyectos" >
		        		<button><img src="images/lupa.png" alt="" title=""></button>
		        	</form>
		        </li>
		      </ul>

		    </div>
		  </nav>
		</div>
	</div>
 <!-- Modal Structure -->
	  <div id="modalsesion" class="modalsesion modal">
	    <div class="modal-content">
	      <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat"><i class="material-icons">clear</i></a>
	      <br><br>
	      <h3>Acceder con FACEBOOK <img src="images/red1.png" alt="" title=""></h3>
	      <div class="lin"><span><i class="material-icons">fiber_manual_record</i></span></div>
	      <p>Acceder con tu cuenta de <span>CORE+</span></p>
	 
	      <form>
		    <div class="input-field">
		    	<img src="images/userlogin.png" alt="" title="">
		      	<input type="text" placeholder="Nombre">
		    </div>
		    <div class="input-field">
		    	<img src="images/userpass.png" alt="" title="" >
		      	<input type="text" placeholder="Contraseña" >
		    </div>
		    <div class="center-left">
		    	<a href="" class="contra">He olvidado mi contraseña</a>
		    </div>
		    <br>
		    <div class="bnt">
		    	<button class="btn">Iniciar sesión</button>
		    	<br>
		    	<a href="">Registrarme</a>
		    </div>
		   </form>
	    </div>
	  </div>
<div class="confooter">
		<div class="container">
			<div class="contce" > 
				<div class="conts">
					<h4>Acerca de nosotros</h4>
					<ul>
						<li><a href="">Qué es CORE+</a></li>
						<li><a href="">Quiénes somos</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
					</ul>
				</div>
				<div class="conts">
					<h4>Acerca de nosotros</h4>
					<ul>
						<li><a href="">Qué es CORE+</a></li>
						<li><a href="">Quiénes somos</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
					</ul>
				</div>
				<div class="conts">
					<h4>Acerca de nosotros</h4>
					<ul>
						<li><a href="">Qué es CORE+</a></li>
						<li><a href="">Quiénes somos</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
					</ul>
				</div>
				<div class="conts">
					<h4>Acerca de nosotros</h4>
					<ul>
						<li><a href="">Qué es CORE+</a></li>
						<li><a href="">Quiénes somos</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
					</ul>
				</div>
				<div class="conts">
					<h4>Acerca de nosotros</h4>
					<ul>
						<li><a href="">Qué es CORE+</a></li>
						<li><a href="">Quiénes somos</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
						<li><a href="">Empleo</a></li>
					</ul>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col s12 m6 l3">
					<a href=""><img src="images/logofoo.png" alt="" title=""></a>
					<p>&copy; 2016 Todos los derechos reservados <br> Diseño por Doctor Marketing</p>
				</div>
				<div class="col s12 m6 l3">
				</div>
				<div class="col s12 m6 l6 rede">
					<a href=""><img src="images/red1.png" alt="" title=""></a>
					<a href=""><img src="images/red2.png" alt="" title=""></a>
					<a href=""><img src="images/red3.png" alt="" title=""></a>
					<a href=""><img src="images/red4.png" alt="" title=""></a>
				</div>
			</div>
		</div>
	</div>

  <!--  Scripts-->
  <script src="js/jquery-1.11.3.min.js"></script>
  <script type="text/javascript" src="js/angular.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>
  <script src="js/angular-materialize.js"></script>
  <script type="text/javascript" src="owl.carousel/owl.carousel.js"></script>
  <script type="text/javascript" src="js/lightslider.js" ></script>
 <script src="js/init.js"></script>
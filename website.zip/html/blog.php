<?php include "include/includes.php"; ?>
</head>
<body >
	<?php $marca = 3; include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container"> 
			 <h1>BLOG</h1>
		</div>
	</div>
	<div class="concontenido">
		<div class="container">
			<div class="conbusca">	
				<?php
					$condition = "";
					$ordenamiento = "";
					if ($_GET['id_categoria'] != null && $_GET['id_categoria'] !="") {
						$condition=" and c.id_categoria = '{$_GET['id_categoria']}' ";
					}

					$ordenamiento="";
					if ($_GET['order'] !=null && $_GET['order'] !="") {
						$_SESSION['ordenamiento']=$_GET['order'];
					}
					if(isset($_SESSION['ordenamiento']) && $_SESSION['ordenamiento'] != ""){
						$db->select("tipo","valor_tipo"," where id_tipo = {$_SESSION['ordenamiento']}");
						$row = $db->fetch_assoc();
						$ordenamiento = $row['valor_tipo'];
					}
				?>			
				<form>
					Ver categoría
					<select onchange="location = this.value">
						<option value="<?php echo $dominio; ?>blog/cod2/">Categoria</option>
						<?php
							$db->select("categoria","id_categoria, amigable_categoria, nombre_categoria","WHERE modulo=50");
							/*$db->last_query();*/
							while ($row = $db->fetch_array()) {
						?>
									<option value="<?php echo $dominio.$row['amigable_categoria'];?>/<?php echo $row['id_categoria'];?>/cod25/"
										<?php 
											if ($_GET['id_categoria'] !=null && $_GET['id_categoria'] !="" && $_GET['id_categoria'] == $row['id_categoria']) {
													echo 'selected';
											}
										?>
									><?php echo $row['nombre_categoria'];?></option>
						<?php
							}
						?>
					</select>
					
					Ordenar por
					<select onchange="location = this.value">
						<?php 
							$db->select("tipo","id_tipo, nombre_tipo","WHERE idr=32");
							/*$db->last_query();*/
							while ($row = $db->fetch_array()) {
						?>
								<option value="<?php echo $dominio;?>blog.php?order=<?php echo $row['id_tipo'];?>"
									<?php
										if ($_SESSION['ordenamiento'] == $row['id_tipo']){
											echo 'selected';
										}
									?>>
									<?php echo $row['nombre_tipo'];?>
								</option>
						<?php
							}	
						?>
					</select>
				</form>
			</div>	

			<ul class="listblog" id="list-blog">
				<?php
					$ip = getRealIP();
					$cant_tanda = 20;
					$db->select("vblog v, categoria c","v.id_matrix"," WHERE v.id_categoria=c.id_categoria AND estado_matrix = 1 {$condition} {$ordenamiento}");
					$num_rows = $db->num_rows();
					$cpadre = array();
					$db->select("vblog v, categoria c","v.id_matrix, v.nombre_matrix, v.referencia_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month, v.descripcion_matrix, v.url_matrix, v.img_matrix, v.estado_matrix, v.inventario_matrix, v.abre_matrix, v.id_categoria, v.amigable_matrix"," WHERE v.id_categoria=c.id_categoria AND estado_matrix = 1 {$condition} {$ordenamiento} LIMIT {$cant_tanda}");
					while ($row = $db->fetch_array()) {
						$cpadre[] = $row;
					}
					foreach($cpadre as $row){
						$mes = $row['month'];
				?>
						<li class="items">
							<div class="row">
								<div class="col s12 m12 l5">
									<a href="<?php echo $dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/';?>">
										<img src="<?php echo $dominio;?>imagenes/blog/imagen1/<?php echo $row['img_matrix'];?>" alt="<?php echo $row['nombre_matrix'];?>" title="<?php echo $row['nombre_matrix'];?>">
									</a>
								</div>
								<div class="col s12 m12 l7">
									<h3><?php echo $row['nombre_matrix'];?></h3>
									<div class="conim">
										<img src="<?php echo $dominio;?>images/imguser.png" alt="" title=""> <?php echo $row['referencia_matrix'];?> <span><?php echo $row['day'].' '.$mesAbre[$mes].' '.$row['year'];?></span>
										<div class="plus">
											<?php
												/*buscar si tiene me gusta*/
												$db->select("relacion","id_relacion","WHERE de='{$row['id_matrix']}' AND con='{$ip}' AND id_tipo=101");												
												if($db->num_rows() <= 0){
											?>
													<img id="btn-me-gusta-<?php echo $row['id_matrix']; ?>" src="<?php echo $dominio;?>images/plusico.png" onclick="meGusta('<?php echo $row['id_matrix'] ?>', '<?php echo $ip; ?>')" alt="" title="">
											<?php
												}
											?>

											<?php
												/*buscar cantidad de me gusta*/
												$row_total_me_gusta = 0;
												$db->select("relacion", "COUNT(id_relacion) as total_me_gusta", "WHERE de='{$row['id_matrix']}' AND id_tipo=101");
												/*$db->last_query();*/
												$row_total_me_gusta = $db->fetch_assoc();
											?>
											<span id="count-me-gusta-<?php echo $row['id_matrix']; ?>"><?php echo $row_total_me_gusta['total_me_gusta']; ?></span>
										</div>
									</div>
									<p><?php echo $row['descripcion_matrix'];?> </p>
									<a href="<?php echo $dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/';?>" class="link">Leer Más</a>
								</div>
							</div>
						</li>
				<?php
					}
				?>
			</ul>
			<input type="hidden" id="total_rows" value="<?php echo $num_rows; ?>" />
			<input type="hidden" id="cant_tanda" value="<?php echo $cant_tanda; ?>" />
			<input type="hidden" id="condicion" value="<?php echo $condicion; ?>" />
			<input type="hidden" id="page" value="1"/>
			<?php 
				if($num_rows > $cant_tanda){
			?>
					<div class="center-align">
						<i class="fa fa-spinner fa-pulse fa-3x fa-fw" id="load-image" style="display:none;"></i><br>
						<a id="load" href="" onclick="return false;" class="link">Blog <i class="fa fa-plus" aria-hidden="true"></i></a>
					</div>
			<?php
				}
			?>
			<script type="text/javascript">
				$(document).ready(function(){
					$('#load').click(function(){
						var loading = false;
						var cant_tanda = $("#cant_tanda").val();
						var total = Math.ceil($('#total_rows').val()/cant_tanda);
						var page = $('#page').val();
						var condicion = $('#condicion').val();
						var ordenamiento = $('#ordenamiento').val();
						if(page <= total && loading==false){
							loading = true;
							$('#load-image').show();
							$.ajax({
								type: "POST",
								url: "<?php echo $dominio; ?>lib/task/server.php",
								data: {
									action: 'last-blog',
									page: page,
									condicion: condicion,
									cant_tanda: cant_tanda,
									ordenamiento: ordenamiento
								},				
								success: function(data){
									$('#list-blog').append(data['news']);
									$('#load-image').hide();
									page++;
									$('#page').val(page);
									$("html, body").animate({scrollTop: $(document).height()-900}, 500);
									loading = false;
									if(page >= total){
										$('#load').hide();
									}
								}
							});
						}else{
							$('#load').hide();
						}
					});
				});

				var meGusta = function(id, ip){
					$.ajax({
						type: "POST",
						url: "<?php echo $dominio; ?>lib/task/server.php",
						data: {
							action: "me-gusta",
							id: id,
							ip: ip
						},				
						success: function(data){
							$("#count-me-gusta-"+id).html(data['total_me_gusta']);
							$("#btn-me-gusta-"+id).hide();
						}
					});
		        }
			</script>
		</div>
	</div>
	<?php include "include/footer.php"; ?>
</body>
</html>
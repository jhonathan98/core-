<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>::Página de Error::</title>
        <style type="text/css">
            <!--
            .Estilo1 {
                font-family: Verdana, Arial, Helvetica, sans-serif;
                font-size: 18px;
            }
            -->
        </style>
    </head>

    <body>
        <div style="text-align:center;"><img src="/logo.png"/></div>
        <div class="Estilo1" style="text-align:center;">
            <p>El contenido solicitado no está disponible.

                Por favor ingrese a nuestro home para encontrar lo que está buscando.</p>
        </div>
        <div class="Estilo1" style="text-align:center;">
            <p><a href="http://coremas.com.co" style="text-decoration:none; color:#F90;">Ir a la página Principal </a></p>
        </div>
    </body>
</html>

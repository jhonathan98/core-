<?php include "include/includes.php"; ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#load').click(function(){
			var loading = false;
			var condicion = $('#condicion').val();
			var cant_tanda = $('#cant_tanda').val();
			if(loading==false){
				loading = true;
				$('#load-image').show();
				$.ajax({
					type: 'POST',
					url: "<?php echo $dominio; ?>lib/task/server.php",
					data: {
						action: 'last-clasificados',
						cant_tanda: cant_tanda,
						condicion: condicion
					},
					success: function(data){
						$('#list-clasificados').append(data['news']);
						$('#load-image').hide();
						$("html, body").animate({scrollTop: $(document).height()-900}, 500);
						loading = false;
						$('#load').hide();
					}
				});
			}else{
				$('#load').hide();
			}
		});
	});
</script>
</head>
<body>
	<?php $marca = 2; include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container">
			<h1>Clasificados</h1>
		</div>
	</div>
	<div class="creacalifica">
		<?php
			if(isset($_SESSION['id_core'])){
		?>
				<a href="<?php echo $dominio; ?>clasificados-core/cod60/" class="link">Crear mi clasificado ></a>
		<?php
			}
		?>
	</div>
	<div class="contcalificados">
		<div class="container">
		    <div class="conbusca">
				<form>
					Ordenar por
					<select id="sel-order-clasificado">
						<option value="">Ordenar por</option>
						<?php
							$db->select("tipo","nombre_tipo, id_tipo","WHERE idr=32 ORDER BY id_tipo");
							/*$db->last_query();*/
							while($row = $db->fetch_array()){
						?>
								<option value="<?php echo $row['id_tipo']; ?>" <?php if($_GET['order'] == $row['id_tipo']){ echo "selected";} ?>><?php echo $row['nombre_tipo']; ?></option>
						<?php
							}
						?>
						<!--<option>Azar</option>-->
					</select>
					Filtrar por
					<select id="filtro-clasificado">
						<option value="">Filtrar por</option>
						<?php
							$db->select("categoria","nombre_categoria, id_categoria","WHERE modulo=49 ORDER BY nombre_categoria");
							/*$db->last_query();*/
							while($row = $db->fetch_array()){
						?>
								<option value="<?php echo $row['id_categoria']; ?>" <?php if($_GET['categoria'] == $row['id_categoria']){ echo "selected";} ?>><?php echo $row['nombre_categoria']; ?></option>
						<?php
							}
						?>
						<!--<option>Azar</option>-->
					</select>
					<a id="resetdrde" class="link btn" style="font-size: 12px; ">Resetear filtros</a>
				</form>
				<script type="text/javascript">
					$(document).ready(function(){
						$("#sel-order-clasificado").change(function(){
							var order = $(this).val();
							var cate = $("#filtro-clasificado").val();
							if(order != null && order != "" && cate == "" ){
								window.location = dominio+"clasificados/"+order+"/cod12/";
							} else if(cate != null && cate != "" && order!=null && order!=""){
								window.location = dominio+"clasificados/"+order+"/"+cate+"/cod14/";
							}
						});
						$("#filtro-clasificado").change(function(){
							var cate = $(this).val();
							var order = $("#sel-order-clasificado").val();
							if(cate != null && cate != "" && order==""){
								window.location = dominio+"clasificados/"+cate+"/cod13/";
							} else if(cate != null && cate != "" && order!=null && order!=""){
								window.location = dominio+"clasificados/"+order+"/"+cate+"/cod14/";
							}
						});
						$("#resetdrde").click(function(){
							location.href = dominio+"clasificados/cod10/";
						})
					});
				</script>
			</div>

			<ul class="row listclasificados" id="list-clasificados">
				<?php
					$condicion = "ORDER BY v.id_matrix DESC";
					/*
					#tipos
					switch($_GET['tipo'){
						case 'recientes':
							$condicion = "ORDER BY v.id_matrix DESC";
							break;
						case 'destacados':
							$condicion = "WHERE v.destacado_matrix = 1";
							break;
						case 'exitosos':
							# code...
							break;
						case 'categorias':
							$condicion = "ORDER BY v.id_categoria DESC";
							break;
						default:
							# code...
							break;
					}
					*/
					#order
					switch ($_GET['order']) {
						case 51:
							$condicion = "ORDER BY v.nombre_matrix ASC";
							break;
						case 52:
							$condicion = "ORDER BY v.nombre_matrix DESC";
							break;
						case 53:
							$condicion = "ORDER BY v.id_matrix ASC";
							break;
						case 54:
							$condicion = "ORDER BY v.id_matrix DESC";
							break;
						case 53:
							$condicion = "ORDER BY RAND()";
							break;
						default:
							$condicion = "ORDER BY v.id_matrix DESC";
							break;
					}
					$condicionca = "";
					if($_GET['categoria']!="") {
						$condicionca = "and v.id_categoria='$_GET[categoria]'";
					}
					$db->select("vclasificados v LEFT JOIN registrado r ON v.referencia_matrix = r.id_registrado, categoria c","v.id_matrix","WHERE c.id_categoria = v.id_categoria AND v.estado_matrix = 1 $condicionca {$condicion}");
					$num_rows = $db->num_rows();
					$cant_tanda = 20;
					$db->select("vclasificados v LEFT JOIN registrado r ON v.referencia_matrix = r.id_registrado, categoria c","v.id_matrix, v.nombre_matrix, v.amigable_matrix, v.referencia_matrix, v.descripcion_matrix, c.img, r.nombre_registrado","WHERE c.id_categoria = v.id_categoria AND v.estado_matrix = 1 $condicionca {$condicion} LIMIT {$cant_tanda}");
					/*$db->last_query();*/
					while ($row = $db->fetch_array()) {
				?>
						<li class="col s12 m6 l3 items">
							<div class="cont">
								<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod11/">
									<img src="<?php echo $dominio; ?>imagenes/categoria/<?php echo $row['img']; ?>" alt="<?php echo $row['nombre_matrix']; ?>" title="<?php echo $row['nombre_matrix']; ?>">
								</a>
								<h4><?php echo $row['nombre_matrix']; ?></h4>
								<p><b>Por:</b> <span><?php echo $row['nombre_registrado']; ?></span></p>
								<?php
								$line=$row['descripcion_matrix'];
									if (preg_match('/^.{1,125}\b/s', $row['descripcion_matrix'], $match))
									{
											$line=$match[0];
									}
								?>
								<p class="txt"><?php echo $line.'...'; ?></p>
							</div>
						</li>
				<?php
					}
				?>
			</ul>
			<br><br>
			<input type="hidden" id="total_rows" value="<?php echo $num_rows; ?>" />
			<input type="hidden" id="cant_tanda" value="<?php echo $cant_tanda; ?>" />
			<input type="hidden" id="condicion" value="<?php echo $condicion; ?>" />
			<?php
				if($cant_tanda < $num_rows){
			?>
				    <div class="center-align">
				    	<i class="fa fa-spinner fa-pulse fa-3x fa-fw" id="load-image" style="display:none;"></i><br>
				    	<a id="load" href="" onclick="return false;" class="link">Ver Todos</a>
				    </div>
			<?php
				}
			?>
		    <br>
		</div>
	</div>

	<?php
		if(isset($_SESSION['id_core'])){
	?>
			<div class="creacalifica">
				<a href="<?php echo $dominio; ?>/clasificados-core/cod60/" class="link">Crear mi clasificado ></a>
			</div>
	<?php
		}
	?>
	<?php include "include/suscribir.php"; ?>
	<?php include "include/footer.php"; ?>
</body>
</html>

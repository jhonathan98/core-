<?php

	if (isset($_POST['register'])) {
		$db->select("registrado","*","where correo_registrado='$_POST[email]'");
		$numd = $db->num_rows();
		if ($numd==0) {
			$dato = array(
				"idr"=>1,
				"nombre_registrado"		=>$_POST['nombre'],
				"correo_registrado" 	=> $_POST['email'],
				"contrasena_registrado" => md5($_POST['repcontra'])
			);
			$db->insert("registrado",$dato);
			$id = $db->insert_id;
			$_SESSION['id_core'] 		= $id;
			$_SESSION['nombre_core'] 	= $_POST['nombre'];
			$_SESSION['correo_core'] 	= $_POST['email'];
			?>
				<script type="text/javascript">location.href="<?php echo $dominio ?>perfil/cod4/";</script>
			<?php
		} else{
			?>
				<script type="text/javascript">alert("El email ya se encuentra registrado"); location.href="<?php echo $dominio; ?>";</script>
			<?php
		}
	}
	if (isset($_POST['sesiond'])) {
		$db->select("registrado","*","where correo_registrado='$_POST[email]' and idr=1");
		$numd = $db->num_rows();
		if ($numd>0) {
			$db->select("registrado","*","where correo_registrado='$_POST[email]' and contrasena_registrado='".md5($_POST['contrasenia'])."' and idr=1");
			$numd = $db->num_rows();
			if ($numd>0) {
				$datos = $db->fetch_array();
				$_SESSION['id_core'] 		= $datos['id_registrado'];
				$_SESSION['nombre_core'] 	= $datos['nombre_registrado'];
				$_SESSION['correo_core'] 	= $datos['correo_registrado'];
				?>
					<script type="text/javascript">location.href="<?php echo $dominio; ?>"; </script>
				<?php
			} else{
				?>
				<script type="text/javascript">alert("Email o contraseña incorrectos"); location.href="<?php echo $dominio; ?>"; </script>
				<?php
			}
		} else{
			?>
				<script type="text/javascript">alert("Email o contraseña incorrectos"); location.href="<?php echo $dominio; ?>"; </script>
			<?php
		}
	}
?>

<div class="header" ng-controller="headercontroller">
		<div class="container">
			<nav>
		    <div class="nav-wrapper">
		      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
		      <a href="<?php echo $dominio;?>" class="brand-logo"><img src="<?php echo $dominio;?>images/logo.png" alt="Core+" title="Core+"></a>
		      <ul id="nav-mobile" class="right hide-on-med-and-down">
		      	<?php if($_SESSION['id_core']==""){ ?>
	        		<li><a href="#modalsesion" class="modal-trigger">Iniciar un proyecto</a></li>
	      		<?php } else{ ?>
	      			<li><a href="<?php echo $dominio;?>inicia-proyecto/cod6/">Iniciar un proyecto</a></li>
	      		<?php } ?>
	        	<li><a href="<?php echo $dominio;?>proyectos/cod21/">Explorar Proyectos</a></li>
		      	<li <?php if($marca == 1){ echo "class='active'"; } ?>>
		      		<a class="dropdown-button" href="#!" data-activates="dropdown1">Corporativo</a>
		      		<ul id="dropdown1" class="dropdown-content submenu">
		        		<li><a href="<?php echo $dominio; ?>quienes-somos/cod8/">Quienes somos</a></li>
		        		<li><a href="<?php echo $dominio; ?>como-funciona/cod30/">Cómo funciona</a></li>
		        		<!--<li><a href="<?php echo $dominio; ?>clasificados/cod10/">Clasificados</a></li>
		        		<li><a href="<?php echo $dominio; ?>blog/cod2/">Blog</a></li>
		        		<li><a href="<?php echo $dominio; ?>eventos/cod7/">Eventos</a></li>
		        		<li><a href="<?php echo $dominio; ?>contacto/cod5/">Contáctenos</a></li>-->
		        	</ul>
		      	</li>

		      	<li class="user"><a class="dropdown-button" href="#!" data-activates="menservic">Servicios</a></li>
		        	<ul id="menservic" class="dropdown-content">
		        		<li <?php if($marca == 2){ echo "class='active'"; } ?>><a href="<?php echo $dominio; ?>clasificados/cod10/">Clasificados</a></li>
				      	<li <?php if($marca == 3){ echo "class='active'"; } ?>><a href="<?php echo $dominio; ?>blog/cod2/">Blog</a></li>
				      	<li <?php if($marca == 4){ echo "class='active'"; } ?>><a href="<?php echo $dominio; ?>eventos/cod7/">Eventos</a></li>
		        	</ul>


		      	<li <?php if($marca == 5){ echo "class='active'"; } ?>><a href="<?php echo $dominio; ?>contacto/cod5/">Contáctenos</a></li>
		      	<!-- proyectos -->

		      	<!-- fin proyectos -->
		        <?php if($_SESSION['id_core']==""){ ?>
		        	<li class="user"><a class="dropdown-button" href="#!" data-activates="dropdown2"><i class="fa fa-user"></i></a></li>
		        	<ul id="dropdown2" class="dropdown-content">
		        		<li><a href="#modalsesion" class="modal-trigger">Acceso</a></li>
		        		<li><a href="#modalregistro" class="modal-trigger">Registro</a></li>
		        	</ul>
		        <?php } else{ ?>
		        	<li >
		        		<?php
		        		 $db->select("registrado","img_registrado","where id_registrado='$_SESSION[id_core]'");
		        		 $datosreg = $db->fetch_array();

						 if($datosreg['img_registrado']!=""){
	                        $img = ((strpos($datosreg['img_registrado'], "http://") === 0) ||
	                                (strpos($datosreg['img_registrado'], "https://") === 0) ||
	                                (strpos($datosreg['img_registrado'], "www.") === 0)) ?
	                                $datosreg['img_registrado'] :
	                                $dominio.$datosreg['img_registrado'];
	                        }else{
	                            $img =$dominio."images/user_imagen.png";
	                        }

						?>
		        		<a class="dropdown-button" href="#!" data-activates="dropdownperfil"><img src="<?php echo $img ?>" id="imgper">Perfil</a>
		        	</li>
		        	<ul id="dropdownperfil" class="dropdown-content">
		        		<li><a href="<?php echo $dominio ?>perfil/cod4/">Mi perfil</a></li>
		        		<li><a ng-click="cerrarsesion()">Cerrar sesión</a></li>
		        	</ul>
		        <?php } ?>
		        <li>
		        	<form id="form_buscador">
		        		<input type="text" placeholder="Buscar Proyectos" >
		        		<button><img src="<?php echo $dominio;?>images/lupa.png" alt="Buscar" title="Buscar"></button>
		        	</form>
		        	<script type="text/javascript">
						$(function(){
							$("#form_buscador").submit(function(){
								console.log('buscar');
								if ($(this).find("input").val()=="") { return false; };
								location.href="<?php echo $dominio ?>buscar/"+$(this).find("input").val()+"/";
								return false;
							});
						});
					</script>
		        </li>
		      </ul>

		      <ul class="side-nav" id="mobile-demo">
		        <li><a href="<?php echo $dominio;?>"><span>INICIAR UN PROYECTO</span></a></li>
		        <li><a href="<?php echo $dominio;?>">Explorar Proyectos</a></li>
		        <li><a href="#modalsesion" class="modal-trigger">Acceso</a></li>
		        <li><a href="#modalregistro" class="modal-trigger">Registro</a></li>
		        <li>
		        	<form>
		        		<input type="text" placeholder="Buscar Proyectos" >
		        		<button><img src="<?php echo $dominio;?>images/lupa.png" alt="Buscar" title="Buscar"></button>
		        	</form>
		        </li>
		      </ul>

		    </div>
		  </nav>
		</div>
</div>

<?php if($_SESSION['id_core']==""){ ?>
 <!-- Modal Structure -->
<div id="modalsesion" class="modalsesion modal">
	<div class="modal-content">
	  <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat"><i class="material-icons">clear</i></a>
	  <br><br>
	  <h3>
	  	<img src="<?php echo $dominio;?>images/red1.png" alt="Facebook" title="Facebook" onclick="loginface()" >

	  	<div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark"></div>
	  	<img src="<?php echo $dominio;?>images/red6.png" alt="Twitter" title="Twitter" style="border-radius:14px !important;" onclick="loginTwitter()" >
	  	<!-- <img src="<?php echo $dominio ?>images/linklogin.png" alt="" title="" style="height: 58px;" onclick="onLinkedInLoad()" > -->
	  	<br>
	  	<script type="in/Login"></script>
	  </h3>
	  <div class="lin"><span><i class="material-icons">fiber_manual_record</i></span></div>
	  <p>Acceder con tu cuenta de <span>CORE+</span></p>

	  <form action="" method="post" id="forsesion">
	  	<input type="hidden" name="sesiond" value="1">
	    <div class="input-field">
	    	<img src="<?php echo $dominio;?>images/userlogin.png" alt="" title="">
	      	<input type="text" placeholder="Email" class="required" rel="email" name="email">
	    </div>
	    <div class="input-field">
	    	<img src="<?php echo $dominio;?>images/userpass.png" alt="" title="" >
	      	<input type="password" placeholder="Contraseña" name="contrasenia" >
	    </div>
	    <div class="center-left">
	    	<a href="" class="contra">He olvidado mi contraseña</a>
	    </div>
	    <br>
	    <div class="bnt">
	    	<button class="btn">Iniciar sesión</button>
	    	<br>
	    	<a href="#modalregistro" class="modal-trigger">Registrarme</a>
	    </div>
	   </form>
	</div>
</div>

<script type="text/javascript">
	$(function(){
		$("#forsesion").submit(function(){
			if (!vacios("#forsesion")) { return false; }
		})
	})
</script>

<div id="modalregistro" class="modalsesion modal">
	<div class="modal-content">
	  <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat"><i class="material-icons">clear</i></a>
	  <br><br>
	  <h3>
	  	<img src="<?php echo $dominio;?>images/red1.png" alt="Facebook" title="Facebook" onclick="loginface()" >
	  	<div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark"></div>
	  	<img src="<?php echo $dominio;?>images/red6.png" alt="Twitter" title="Twitter" onclick="loginTwitter()" >
	  	<img src="<?php echo $dominio ?>images/linklogin.png" alt="" title="" style="height: 58px;" onclick="onLinkedInLoad()" >
	  </h3>
	  <div class="lin"><span><i class="material-icons">fiber_manual_record</i></span></div>
	  <p>Registrate con tu cuenta de <span>CORE+</span></p>

	  <form action="" method="post" id="registroform">
	    <input type="hidden" name="register" value="1">
	    <div class="input-field">
	    	<img src="<?php echo $dominio;?>images/userlogin.png" alt="" title="">
	      	<input type="text" class="required" name="nombre" placeholder="Nombre">
	    </div>
	    <div class="input-field">
	    	<img src="<?php echo $dominio;?>images/userlogin.png" alt="" title="">
	      	<input type="text" class="required" rel="email" name="email" placeholder="Email">
	    </div>
	    <div class="input-field">
	    	<img src="<?php echo $dominio;?>images/userpass.png" alt="" title="" >
	      	<input type="password" class="required" name="contra" placeholder="Contraseña" >
	    </div>
	    <div class="input-field">
	    	<img src="<?php echo $dominio;?>images/userpass.png" alt="" title="" >
	      	<input type="password" class="required" name="repcontra" placeholder="Repetir Contraseña" >
	    </div>
	    <br>
	    <div class="bnt">
	    	<button class="btn">Registrarme</button>
	    	<br>
	    	<a href="#modalsesion" class="modal-trigger" >Inicia sesión</a>
	    </div>
	   </form>
	</div>
</div>

<script type="text/javascript">
	$(function(){

 		$("#registroform").submit(function(){
			if (!vacios("#registroform")) { return false; }
			if ($(this).find("input[name=contra]").val() != $(this).find("input[name=repcontra]").val() ) {
				alert("Las contraseñas no coinciden");
				return false;
			}
		});
		$(window).scroll(function(){
			var scro = $(this).scrollTop();
			if (scro>150) {
				$(".header ").addClass("headerFixed");
			} else{
				$(".header ").removeClass("headerFixed");
			}
		})
	})
</script>
<!-- Login -->
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1859389797650363',
      cookie     : true,
      version    : 'v2.5'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));


  function loginface(){

        FB.login(function(response) {
            if (response.status==="connected") {
                getFacebookData();
            }
        }, {scope: 'email,public_profile'});
    }
    var getFacebookData =  function() {
        FB.api('/me/',{fields:'id,name,email,picture,gender'}, function(response) {
                $.ajax({
                data: {"cod":"inicio_facebook","email":response.email,"nombre":response.name,"images":response.picture.data.url,"id":response.id,"sexo":response.gender},
                      url:   dominio+"lib/ajax_hlo.php",
                      type:  'POST',
                      beforeSend: function ()
                      {

                      },
                      success:  function (datos) {
                        console.log(datos);
                        if (datos==1){
                        	location.href=dominio+"perfil/cod4/";
                        } else if (datos==2){
                        	location.href=dominio;
                        }
                      }
                  },{scope: 'email,public_profile'});
        });
    }
    function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;

        $.ajax({
            data: {"cod":"inicio_google","email":profile.getEmail(),"nombre":profile.getName(),"id":id_token,"imagen":profile.getImageUrl()},
          url:   dominio+"lib/ajax_hlo.php",
          type:  'POST',
          beforeSend: function ()
          {

          },
          success:  function (datos) {
            console.log(datos);
            if (datos==1){
            	location.href=dominio+"perfil/cod4/";
            } else if (datos==2){
            	location.href=dominio;
            }
          }
      });
    };
</script>

<script type="text/javascript">

  function displayProfiles(profiles) {
    member = profiles.values[0];

    $.ajax({
            data: {"cod":"inicio_linke","email":member.emailAddress,"nombre":member.firstName,"apellido":member.lastName,"id":member.id },
          url:   dominio+"lib/ajax_hlo.php",
          type:  'POST',
          beforeSend: function ()
          {

          },
          success:  function (datos) {

            if (datos==1){
            	location.href=dominio+"perfil/cod4/";
            } else if (datos==2){
            	location.href=dominio;
            }
          }
      });
  }
</script>
<?php } else{ ?>

<div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark" style="display: none;"></div>
<script type="text/javascript">
	function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
    }
    function displayProfiles(profiles) {}
</script>
<?php } ?>
<script type="text/javascript" src="https://platform.linkedin.com/in.js">
  api_key: 78ynz03ci3is41
  onLoad: onLinkedInLoad
  authorize: true
  scope: r_basicprofile r_emailaddress
</script>

<script type="text/javascript">

  function onLinkedInLoad() {
    IN.Event.on(IN, "auth", onLinkedInAuth);
  }

  function onLinkedInAuth() {

    IN.API.Profile("me").fields("id","first-name", "last-name", "email-address").result(displayProfiles);
  }


</script>

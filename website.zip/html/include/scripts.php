<?php
	$valor=variable(1,1); echo base64_decode($valor[2]);
	$valor=variable(2,1); echo base64_decode($valor[2]);
	$valor=variable(3,1); echo base64_decode($valor[2]);
	$valor=variable(5,1); echo base64_decode($valor[2]);
?>
 

   	
	    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="js/plugins/owl/owl.carousel.css">
 		<link rel="stylesheet" href="js/plugins/owl/owl.theme.default.min.css">
 		<link rel="stylesheet" href="js/plugins/bootstrap-select/css/bootstrap-select.min.css">
 		<link rel="stylesheet" href="styles/main.css">
 		<link rel="stylesheet" href="styles/helpers.css">
 		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">


		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	    <!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	    <![endif]-->
		<link rel="stylesheet" href="js/plugins/bootstrap-select/css/bootstrap-select.css">
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
		<script type="text/javascript" src="js/plugins/cloud-zoom-master/cloud-zoom.js"></script>
        <link rel="stylesheet" href="js/plugins/cloud-zoom-master/cloud-zoom.css" type="text/css">
        
               

<div class="confooter">
	<div class="container">
		<div class="contce" >
			<?php
				$cpadre = array();
				$db->select("categoria c, venlace e","c.id_categoria, c.nombre_categoria","WHERE c.id_categoria = e.id_categoria GROUP BY c.id_categoria ORDER BY c.ubica_categoria");
				/*$db->last_query();*/
				while ($arraypadre = $db->fetch_array()) {
					$cpadre[] = $arraypadre;
				}
				foreach($cpadre as $row_cat){
			?>
					<div class="conts">
						<h4><?php echo $row_cat['nombre_categoria'] ?></h4>
						<ul>
							<?php
								$db->select("venlace","nombre_matrix, url_matrix, abre_matrix","WHERE id_categoria = '{$row_cat['id_categoria']}' ORDER BY ubica_matrix");
								/*$db->last_query();*/
								while ($row = $db->fetch_array()){
							?>
									<li><a href="<?php echo $row['url_matrix']; ?>" target="<?php if($row['abre_matrix']==25){echo '_blank';}else{echo '_self';} ?>"><?php echo $row['nombre_matrix']; ?></a></li>
							<?php
								}
							?>
						</ul>
					</div>
			<?php
				}
			?>
		</div>
		<hr>
		<div class="row">
			<div class="col s12 m6 l3">
				<a href="<?php echo $dominio;?>"><img src="<?php echo $dominio;?>images/logofoo.png" alt="core+" title="core+"></a>
				<?php
					$db->select("vayuda", "contenido_matrix", "WHERE id_subcategoria = 15");
					$row = $db->fetch_assoc();
					echo $row['contenido_matrix'];
			 	?>
			</div>
			<div class="col s12 m6 l3">
			</div>
			<div class="col s12 m6 l6 rede">
				<a href="<?php $valor=variable(11,1); echo $valor[0]; ?>" target="_blank"><img src="<?php echo $dominio;?>images/red-1.png" alt="facebook" title="facebook"></a>
				<a href="<?php $valor=variable(10,1); echo $valor[0]; ?>" target="_blank"><img src="<?php echo $dominio;?>images/red2.png" alt="twitter" title="twitter"></a>
				<a href="<?php $valor=variable(12,1); echo $valor[0]; ?>" target="_blank"><img src="<?php echo $dominio;?>images/red3.png" alt="youtube" title="youtube"></a>
				<a href="<?php $valor=variable(18,1); echo $valor[0]; ?>" target="_blank"><img src="<?php echo $dominio;?>images/red4.png" alt="linkedin" title="linkedin"></a>
			</div>
		</div>
	</div>
</div>



			<div id="actionbar">
				<div class="container">

					<div class="row">
						<span id="menuToggle"><i class="fa fa-bars"></i></span>
						<ul id="nav-menu" data-side-menu class="">
							<li class="active"><a href="index.php" >HOME</a></li>
							<li><a href="about.php">ABOUT </a></li>
				            <!--<li ><a >Conocer</a>
							   <ul class="submenu" >
									<li><a href="conocer.php">Test 1</a></li>
									<li><a href="conocer.php">Test 2</a></li>
									<li><a >Subnivel 3</a>
										<ul >
											<li>
												<a href="conocer.php">Nivel 3</a>
											</li>
											<li>
												<a href="conocer.php">Nivel 3</a>
											</li>
											<li>
												<a href="conocer.php">Nivel 3</a>
											</li>
										</ul>
									</li>
							   </ul>
							 </li>-->
							 <li><a href="shop.php">SHOP</a></li>
							 <li><a href="blog.php">BLOG</a></li>
							 <li><a href="contact.php">CONTACT</a></li>

						</ul>
					</div>
				</div>
			</div>

<div class="container top">
	<ul class="text">
		<li>
			<div class="imagenico">
				<img src="<?php echo $dominio; ?>img/icons/seguro.png" alt="Registro" title="Registro">
			</div>
			<div class="textico">Registro</div>
		</li>
		<li>
			<div class="imagenico">
				<img src="<?php echo $dominio; ?>img/icons/90minutos.png" alt="Iniciar Sesión" title="Iniciar Sesión">
			</div>
			<div class="textico">Iniciar Sesión</div>
		</li>
		<li>
			<div class="imagenico">
				<img src="<?php echo $dominio; ?>img/icons/precios.png" alt="Carrito de Compras" title="Carrito de Compras">
			</div>
			<div class="textico">Carrito de Compras</div>
		</li>
		<li>
			<div class="imagenico">
				<img src="<?php echo $dominio; ?>img/icons/sinSalir.png" alt="Términos y Condiciones" title="Términos y Condiciones">
			</div>
			<div class="textico">Términos y Condiciones</div>
		</li>
		<li>
			<div class="imagenico">
				<img src="<?php echo $dominio; ?>img/icons/phone.png" alt="">
			</div>
			<div class="textico">
				Llámanos: <br> <?php $valor=variable(9,1); echo $valor[0]; ?>
			</div>
		</li>
	</ul>
</div>
<!--End Top-->
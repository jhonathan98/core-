<?php include "include/includes.php"; ?>
</head>
<body >
	<?php $marca = 1; include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container"> 
			<h1>Cómo funciona</h1>
		</div>
	</div>
	<div class="divbanner"></div>	
	<div class="conpasopaso">
		<div class="container">
			<h3>PASO A PASO</h3>
			<div class="center-align">
				<br>
				<a href="" class="link">Empezar Guía</a>
			</div>
			<br><br>
			<ul class="listcomofunciona">

				<?php 	
					$db->select("vcomo","id_matrix, nombre_matrix, amigable_matrix, descripcion_matrix, codigo_matrix, url_matrix, abre_matrix","ORDER BY ubica_matrix");
					/*$db->last_query();*/
					while ($row = $db->fetch_array()) {
				?>
						<li class="items">					
							<div class="cont">
								<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod31/"><h4><?php echo $row['codigo_matrix'];?></h4></a>
								<h5><?php echo $row['nombre_matrix'];?></h5>
								<p><?php echo $row['descripcion_matrix'];?></p>
								<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod31/"><img src="<?php echo $dominio;?>images/imgpluscircle.png" alt="<?php echo $row['nombre_matrix'];?>" title="<?php echo $row['nombre_matrix'];?>"></a>
							</div>
						</li>
				<?php
					}						
			 	?>
			</ul>
		</div>
	</div>
	<?php include "include/suscribir.php"; ?>
	<?php include "include/footer.php"; ?>
</body>
</html>
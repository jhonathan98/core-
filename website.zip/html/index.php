<?php include "include/includes.php"; ?>

</head>
<body >
	<?php include "include/header.php"; ?>
	<div class="owl-carousel owl-theme banner" id="bannerslider">
		<?php
			$db->select("vslide","nombre_matrix, descripcion_matrix, referencia_matrix, abre_matrix, url_matrix, img_matrix","ORDER BY ubica_matrix");
			/*$db->last_query();*/
			while ($row = $db->fetch_array()) {
		?>
				<div class="item" style="background-image: url(<?php echo $dominio;?>imagenes/slide/imagen1/<?php echo $row['img_matrix'];?>);">
			    	<div class="txtt">
				    	<div class="txt">
					    	<h3><?php echo $row['nombre_matrix'];?></h3>
					    	<p><?php echo $row['descripcion_matrix'];?></p>
					    	<a href="<?php echo $row['url_matrix'];?>"  target="<?php if($row['abre_matrix']==25){echo '_blank';}else{echo '_self';} ?>"><?php echo $row['referencia_matrix'];?></a>
					    </div>
					</div>
			    </div>
		<?php
			}
		?>
	</div>
	<div class="contenido contproyectos">
		<div class="container">
			<h3 class="titles">PROYECTOS</h3>
			<!--ul class="menupro">
		        <li class="active"><a href="#test1">Recientes</a></li>
		        <li class=""><a class="active" href="#test2">Destacados</a></li>
		        <li class=""><a href="#test3">Exitos</a></li>
		        <li class=""><a href="#test4">Categorías</a></li>
		    </ul-->
		    <div class="listaproyectos" id="sliderproyecto">
		    	<?php
	    			$db->select("proyecto INNER JOIN registrado on proyecto.id_registrado = registrado.id_registrado inner join departamento on proyecto.departamento_proyecto = departamento.id_departamento inner join pais on proyecto.pais_proyecto = pais.codigo_pais","*","order by nombre_proyecto asc");

	    			$recoda = array();
	    			while ($datos = $db->fetch_array()) {
	    				$recoda[] = $datos;
	    			}

	    			foreach ($recoda as $datos) {
	    				$db->select("donaciones as d ","*","where d.proyecto=$datos[id_proyecto]");
	    				$ttdonacion=0;
	    				while($datosdona = $db->fetch_array()){
		    				$ttdonacion += $datosdona[valor];
		    				if ($datosdona[recompensa]>0) {
				    			$numd = $datosdona[recompensa];
				    			$dona = $datos['valor_recompensa'.$numd];
				    			$ttdonacion+=$dona;
				    		}
			    		}

	    				$porcen = round(($ttdonacion / $datos['valor_proyecto'])*100);
	    				$maspor = $porcen;
	    				if ($porcen>100) {
	    					$porcen=100;
	    					$maspor = 100;

	    				}
	    				$restanp = round(100 - $porcen);

		     			$ip  = $datos['id_proyecto'];
		     			$db->select("imagenes_proyecto","*","where id_proyecto = $ip ");
						//echo  $db->last_query();
						$imgpro = $db->fetch_array();

						$totalFecha = totalFechas($datos['fecha_publicacion'], $datos['plazo_financiacion_proyecto']);
						$diasfaltan = restaFechas($datos['plazo_financiacion_proyecto'],date("Y-m-d"));

						if($diasfaltan < 0){ $diasfaltan = 0; }
						$procfechdi = ($diasfaltan/$totalFecha) * 100;
						$procfechdi = round($procfechdi);

			    	?>

				    	<div style="cursor: pointer;" stclass="col s12 m6 l3 items" onclick="window.location.href='<?php echo $dominio ?><?php echo $ip;?>/cod20/'">
				    		<div class="cont">
								<div class="contlike">
									<img src="<?php echo $dominio ?>images/plusico.png" alt="" title="" rel="<?php echo $datos['id_proyecto'] ?>" <?php if ($_SESSION['id_core'] != ""){ ?> class="btonmeguta" <?php  } ?> >

									<!--cuantos likes he recibido-->
									<?php
										$db->select("relacion","cantidad","where id_tipo=104 and de='$datos[id_proyecto]'");
										// echo $db->last_query();
										$canti = $db->num_rows();
									?>
									<span><?php echo $canti;?></span>
								</div>
				    			<div class="contimg">
				    				<?php
				    				if ($imgpro['ruta_imagen'] != "") {
				    					$img = $dominio.$imgpro['ruta_imagen'];
				    				}else{
				    					$img = $dominio."images/imgpro.png";
				    				} ?>
				    				<div class="imgcont" style="background-image: url(<?php echo $img ?>);"></div>
				    				<div class="contporc align-center">
				    					<div class="row">
				    						<div class="col s12 m12 l4 center-align">
				    							<br><br><br><br><br><br>
				    							<b style="margin-top:20px !important;"class="reca">Recaudos</b>
				    							<span><b>$<?php echo number_format($ttdonacion,0,",","." ); ?></b></span>

				    						</div>
				    						<div class="col s12 m12 l3 center-align">
				    							<br><br><br>
				    							<div class="c100 p<?php echo $procfechdi; ?> small">
								                    <span style="line-height: 18px; padding-top: 7px;"><?php echo $diasfaltan; ?><br>Días</span>
								                    <div class="slice">
								                        <div class="bar"></div>
								                        <div class="fill"></div>
								                    </div>
								                </div>
																<b class="reca">Restantes</b>
							    							<span><b><?php echo $restanp; ?>%</b></span>
				    						</div>
				    						<div class="col s12 m12 l5 center-align">
				    							<br>
				    							<div class="c100 p<?php echo $porcen; ?>">
								                    <span><?php echo $maspor; ?>%</span>
								                    <div class="slice">
								                        <div class="bar"></div>
								                        <div class="fill"></div>
								                    </div>
								                </div>
																<b class="reca">Meta</b>
							    							<span><b>$<?php echo number_format($datos['valor_proyecto'],0,",","." ); ?></b></span>
				    						</div>
				    					</div>
				    					<div class="pa">
					    					<h4><b><?php echo $datos['nombre_proyecto']; ?></b></h4>
												<?php
													$line=$datos['nombre_registrado'];
													if (preg_match('/^.{1,20}\b/s', $datos['nombre_registrado'], $match))
													{
															$line=$match[0];
													} ?>
							    			<p><b>Por:</b> <span><?php echo $line;?></span></p>
							    			<p><b>
							    			<?php echo $datos['nombre_departamento'].", ".$datos['nombre_pais']; ?>
							    			</b></p>
												<?php
												$line=$datos['descripcion_proyecto'];
													if (preg_match('/^.{1,60}\b/s', $datos['descripcion_proyecto'], $match))
													{
													    $line=$match[0];
													}
												?>
							    			<p class="gray"><?php echo $line."..."; ?></p>
							    		</div>
						            </div>
				    			</div>
				    		</div>
				    	</div>
		    	<?php
		    		}
		    	?>
		    </div>
		    <br><br>
		    <div class="center-align">
		    	<a href="<?php echo $dominio ?>proyectos/cod21/" class="link">Ver <i class="fa fa-plus" aria-hidden="true"></i></a>
		    </div>
		    <br><br>
		</div>
	</div>
	<div class="contcalificados">
		<div class="container">
			<h3>CLASIFICADOS</h3>
			<br>
			<ul id="slidercalificados" class="listclasificados">
				<?php
					$db->select("vclasificados v LEFT JOIN registrado r ON v.referencia_matrix = r.id_registrado","v.*, r.nombre_registrado","WHERE v.estado_matrix = 1 AND destacado_matrix = 1 ORDER BY ubica_matrix");
					/*$db->last_query();*/
					while ($row = $db->fetch_array()) {
				?>
						<li class="items">
							<div class="cont">
								<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod11/">
									<div class="img-content" style="background-image: url(<?php echo $dominio;?>imagenes/clasificados/imagen1/pequena/<?php echo $row['img_matrix'];?>); background-size: contain; background-repeat: no-repeat; background-position: center;">
										<!--<img src="<?php echo $dominio;?>imagenes/clasificados/imagen1/<?php echo $row['img_matrix'];?>" alt="<?php echo $row['nombre_matrix'];?>" title="<?php echo $row['nombre_matrix'];?>">-->
									</div>
								</a>
								<h4><?php echo  $row['nombre_matrix'];?></h4>
								<p>
									<b>Por:</b> <span><?php echo  $row['nombre_registrado'];?></span><br>
									<span><?php echo $row['mail_matrix'];?></span>
								</p>
								<?php
								$line=$row['descripcion_matrix'];
									if (preg_match('/^.{1,60}\b/s', $row['descripcion_matrix'], $match))
									{
											$line=$match[0];
									}
								?>
								<p class="txt"><?php echo $line."...";?></p>
							</div>
						</li>
				<?php
					}
			 	?>
			</ul>
			<br><br>
			<div class="center-align">
				<a href="<?php echo $dominio;?>clasificados/cod10/" class="link">Ver <i class="fa fa-plus" aria-hidden="true"></i></a>
			</div>
			<br>
		</div>
	</div>

	<div class="contblog">
		<div class="container">
			<h3>BLOG <i class="fa fa-plus" aria-hidden="true"></i></h3>
			<br>
			<ul class="listblog" id="sliderblog">
				<?php
					$db->select("vblog v, categoria c","v.id_matrix, v.nombre_matrix, v.referencia_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month, v.descripcion_matrix, v.url_matrix, v.img_matrix, v.estado_matrix, v.inventario_matrix, v.abre_matrix, v.id_categoria, v.amigable_matrix"," WHERE v.id_categoria=c.id_categoria AND estado_matrix = 1 ORDER BY evento_matrix DESC LIMIT 12");
					while ($row = $db->fetch_array()) {
						$mes=$row['month'];
				?>
						<li class="items">
							<div class="cont">
								<a href="<?php echo $dominio.$row['amigable_matrix'].'/'.$row['id_matrix'].'/cod23/';?>">
									<img src="<?php echo $dominio;?>imagenes/blog/imagen1/pequena/<?php echo $row['img_matrix'];?>" alt="<?php echo $row['nombre_matrix'];?>" title="<?php echo $row['nombre_matrix'];?>">
								</a>
								<h4><?php echo $row['nombre_matrix'];?></h4>
								<p><b>Por: </b> <span><?php echo $row['referencia_matrix'];?></span>
									<?php
										$line=$row['descripcion_matrix'];
										if (preg_match('/^.{1,60}\b/s', $row['descripcion_matrix'], $match))
										{
												$line=$match[0];
										} ?>
								<p><?php echo $line."...";?></p>
							</div>
						</li>
				<?php
					}
				?>
			</ul>
			<br><br>
			<div class="center-align">
				<a href="<?php echo $dominio;?>blog/cod2/" class="link">Ver <i class="fa fa-plus" aria-hidden="true"></i></a>
			</div>
			<br>
		</div>
	</div>

	<div class="conteventos">
		<div class="container">
			<h3>EVENTOS Y NOTICIAS RECIENTES</h3>
			<br>
			<ul class="listeventos row cuaevento" id="slidereventos">
				<?php
					$db->select("vevento v, categoria c", "v.id_matrix, v.nombre_matrix, v.amigable_matrix, v.img_matrix, v.descripcion_matrix, v.evento_matrix, v.ciudad_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month", "WHERE v.id_categoria = c.id_categoria AND v.evento_matrix > CURDATE() ORDER BY v.evento_matrix DESC LIMIT 12");
					/*$db->last_query();*/
					while($row = $db->fetch_array()){
						$mes=$row['month'];
				?>
						<li class="items">
							<div class="cont">
								<div class="row">
									<div class="conimg col s12 m12 l12">
										<div class="imgbg" style="background-image: url(<?php echo $dominio; ?>imagenes/evento/imagen1/pequena/<?php echo $row['img_matrix']; ?>);"></div>
									</div>
									<div class="contxt col s12 m12 l12 animate">
										<h3><?php echo $row['nombre_matrix']; ?></h3>
										<div class="contmacal">
											<div class="col s12 m12 l12">
												<img src="<?php echo $dominio; ?>images/icomap1.png" alt="" title=""> <span><?php echo $row['ciudad_matrix']; ?></span>
											</div>
											<div class="col s12 m12 l12">
												<img src="<?php echo $dominio; ?>images/icomap2.png" alt="" title=""> <?php echo $row['day'].' '.$mesAbre[$mes].' '.$row['year'];?>
											</div>
										</div>
										<div class="lifle">
											<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod73/" ><img src="<?php echo $dominio; ?>images/flecharara.png" alt="<?php echo $row['nombre_matrix']; ?>" title="<?php echo $row['nombre_matrix']; ?>"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
				<?php
					}
				?>
			</ul>
			<br><br>
			<div class="center-align">
				<a href="<?php echo $dominio;?>eventos/cod7/" class="link">Ver <i class="fa fa-plus" aria-hidden="true"></i></a>
			</div>
			<br>
		</div>
	</div>

	<div class="contcomofunciona">
		<div class="container">
			<h3>CÓMO FUNCIONA</h3>
			<div class="contb">
				<?php
					$db->select("vcomo","nombre_matrix, codigo_matrix, referencia_matrix, amigable_matrix, id_matrix","ORDER BY ubica_matrix limit 3");
						/*$db->last_query();*/
					$i=0;
					while ($row = $db->fetch_array()) {
						$i++;
				?>
					<div class="conn">
						<a href="<?php echo $dominio.$row['amigable_matrix'];?>/<?php echo $row['id_matrix'];?>/cod31/"><h4 <?php
							if ($i==2 ) {
								echo "class='bg'";
							}
						?>><?php echo $row['codigo_matrix'];?></h4></a>
						<h5><?php echo $row['nombre_matrix'];?></h5>
						<p><?php echo $row['referencia_matrix'];?></p>
					</div>
				<?php
					if($i < 3){
				?>
						<div class="conn fle">
							<img src="<?php echo $dominio;?>images/drfle.png" alt="" title="">
						</div>
				<?php
					}
				?>

			<?php
				}
			?>
			</div>
		</div>
	</div>

	<div class="concomienza">
		<div class="container">
			<?php
				$db->select("vayuda","nombre_matrix, contenido_matrix","WHERE id_subcategoria = 100");
				$row = $db->fetch_assoc();
			?>
			<h3><?php echo $row['nombre_matrix']; ?></h3>
			<?php echo $row['contenido_matrix']; ?>
			<br>
			<div class="btnlin">
				<a href="proyectos_list.php" class="link">Explorar Proyectos</a>
				<?php


 					if($_SESSION['id_core']==""){ ?>
			        		<a href="#modalsesion" class="link bg modal-trigger">Iniciar un proyecto</a>
			      		<?php } else{ ?>
			      			<a href="<?php echo $dominio;?>inicia-proyecto/cod6/" class="link bg">Iniciar un proyecto</a>
			      		<?php }


				?>
			</div>
		</div>
	</div>

	<div class="contsuscri">
		<div class="container">
			<div class="row">
				<div class="col s12 m12 l7">
					<?php
						$db->select("vayuda","contenido_matrix"," WHERE id_subcategoria=71");
						$rowh = $db->fetch_assoc();
						echo $rowh["contenido_matrix"];
					?>
				</div>

				<div class="col s12 m12 l5">
					<form id="form-suscribir">
						<input type="hidden" value="suscribir" name="action">
						<input type="text" rel="email" name="suscribir" placeholder="Ingresa tu correo" class="required">
						<button>Suscribirse</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="contpatrocina">
		<div class="container">
			<h3>ALIADOS ESTRATEGICOS</h3>
			<ul id="sliderpatrocina" class="patrocina">
				<?php
					$db->select("vpatrocinantes","img_matrix, url_matrix, abre_matrix, nombre_matrix","ORDER BY ubica_matrix");
					/*$db->last_query();*/
					while ($row = $db->fetch_array()) {
				?>
						<li class="items"><a href="<?php echo $row['url_matrix']; ?>" target="<?php if($row['abre_matrix']==25){echo '_blank';}else{echo '_self';} ?>"><img src="<?php echo $dominio;?>imagenes/patrocinantes/imagen1/<?php echo $row['img_matrix'];?>" alt="<?php echo $row['nombre_matrix'];?>" title="<?php echo $row['nombre_matrix'];?>"></a></li>
				<?php
					}
				?>
			</ul>
		</div>
	</div>
	<?php include "include/footer.php"; ?>
</body>
</html>

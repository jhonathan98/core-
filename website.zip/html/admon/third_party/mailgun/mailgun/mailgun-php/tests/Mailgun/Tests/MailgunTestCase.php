<?PHP

namespace Mailgun\Tests;

use Guzzle\Tests\GuzzleTestCase;

abstract class MailgunTestCase extends GuzzleTestCase
{
}

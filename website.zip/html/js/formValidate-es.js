var INVALID_EMAIL_ADDRESS 	= "Correo electrónico invalido";
var INVALID_PHONE_NUMBER 	= "Teléfono invalido";
var FIELD_REQUIRED 			= "Este campo es requerido";
var GIF_JPG_PNG_FORMAT 		= "Los formatos requeridos son gif,jpg y png.";
var CHARACTERS_MIN 	= "Contenido mayor o igual a 20 caracteres.";
var VALID_PSW 		= "La contraseña debe contener como mínimo una letra mayúscula , una letra minúscula y un número.";
var INVALID_URL 	= "La URL de tu video no es válida. ";
var CHARACTERS_NUM  = "Debes digitar una cantidad";
var INVALID_EMAIL_ADDRESS = "Invalid email address";
var INVALID_PHONE_NUMBER = "Invalid phone number";
var FIELD_REQUIRED = "This field is required";
var GIF_JPG_PNG_FORMAT = "file format must be gif, jpg or png.";
var CHARACTERS_MIN = "20 characters minimum";
var VALID_PSW = "The password must contain at least one uppercase letter, one lowercase letter and a number.";
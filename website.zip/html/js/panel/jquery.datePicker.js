<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /Simpla-Admin/resources/scripts/jquery.datePicker.js was not found on this server.</p>
<hr>
<address>Apache/2.0.54 Server at demo.ponjoh.com Port 80</address>
</body></html>

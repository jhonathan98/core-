<?php include "include/includes.php"; ?>
</head>
<body >
	<?php $marca = 2; include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container"> 
			<h1>Clasificados</h1>
		</div>
	</div>
	<div class="detalleblog">
		<div class="container">
			<div class="row">
				<?php
					$db->select("vclasificados v LEFT JOIN registrado r ON v.referencia_matrix = r.id_registrado, categoria c","v.nombre_matrix, v.url_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month, v.referencia_matrix, v.contenido_matrix, v.mail_matrix, c.img, c.nombre_categoria, r.nombre_registrado","WHERE c.id_categoria = v.id_categoria AND v.id_matrix = '{$_GET['id']}'");
					$row = $db->fetch_assoc();
					$mes = $row['month'];
				?>
				<div class="col s12 m12 l8">
					<h2 class="tcla"><?php echo $row['nombre_matrix']; ?></h2>
					<div class="conim">
						<span><?php echo $row['mail_matrix'];?></span><br>
					</div>
					<div class="conim">
						<span><?php echo $row['day'].' '.$mesAbre[$mes].' '.$row['year'];?></span><br><br>
						<img src="<?php echo $dominio; ?>images/imguser.png" alt="<?php echo $row['referencia_matrix']; ?>" title="<?php echo $row['referencia_matrix']; ?>"> <?php echo $row['nombre_registrado']; ?>
					</div>
					<br><br>
					<div class="tpc">
						<img src="<?php echo $dominio; ?>imagenes/categoria/<?php echo $row['img']; ?>" alt="<?php echo $row['nombre_categoria']; ?>" title="<?php echo $row['nombre_categoria']; ?>">
						<?php echo $row['nombre_categoria']; ?>
					</div>
					<br>
					<?php echo $row['url_matrix']; ?>
					<br>
					<div class="conim">
						<div class="conu">
							Compartir
							<?php include "include/compartir.php"; ?>
						</div>
					</div>
					<br><br>
					<div class="txt">
						<?php echo $row['contenido_matrix']; ?>
						<br><br>
					</div>
				</div>
				<div class="col s12 m12 l4">
					<div class="conizq sinfon">
						<h4>Clasificados Recientes</h4>
						<ul>
							<?php
								$db->select("vclasificados", "nombre_matrix, id_matrix, amigable_matrix", "ORDER BY evento_matrix DESC LIMIT 6");
								/*$db->last_query();*/
								while ($row = $db->fetch_array()) {
							?>
									<li>
										<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod11/">
											<i class="material-icons">fiber_manual_record</i> <?php echo $row['nombre_matrix']; ?>
										</a>
									</li>
							<?php
								}
							?>
						</ul>

					</div>					

				</div>

			</div>

		</div>

	</div>

	<?php
		if(isset($_SESSION['id_core'])){
	?>
			<div class="creacalifica">
				<a href="<?php echo $dominio; ?>clasificados-core/cod60/" class="link">Crear mi clasificado &gt;</a>
			</div>
	<?php
		}
	?>
	<?php include "include/suscribir.php"; ?>
	<?php include "include/footer.php"; ?>
</body>
</html>
<?php include "include/includes.php"; ?>
<?php
	if (isset($_POST['updateuser'])) {
		$datos = array(
			"nombre_registrado"=>$_POST[nombre],
			"nacio_registrado"=>$_POST[nacio],
			"sexo_registrado"=>$_POST[sexo],
			"pais_registrado"=>$_POST[pais],
			"departamento_registrado"=>$_POST[departamento],
			"ciudad_registrado"=>$_POST[ciudad],
			"web_registrado"=>$_POST[web],
			"esposa_registrado"=>$_POST['trabaja'],
			"empresa_registrado"=>$_POST[empresa],
			"cargo_registrado"=>$_POST[cargo],
			"perfil_registrado"=>$_POST[desenpenia],
			"mensaje_registrado"=>$_POST[descripcion],
		);
		$db->update("registrado",$datos,"where id_registrado='$_SESSION[id_core]'");

		//Nombre archivo
		$archivo = $_FILES["imgregi"]['name'];
		//Extencion de archivo
		$datos = explode(".", $archivo);
		$ext = end($datos);
		//Tamaño del archivo opcional
		$tamano = $_FILES["imgregi"]['size'];
		//Type de archivo opcional
		$tipo = $_FILES["imgregi"]['type'];
		if ($archivo != "")
		{
			$db->select("registrado","img_registrado","where id_registrado='$_SESSION[id_core]'");
			$datosr = $db->fetch_array();
			if ($datosr['img_registrado']!="") {
				unlink($datosr['img_registrado']);
			}
			//nombre archivo personalizado
			$nombre_ar = $_SESSION[id_core].rand(1,100000).".".$ext;
			//Ruta donde se guarda el archivo
			$destino = "imagenes/registrado/".$nombre_ar;
			//Seguarda el archivo en la ruta y nombre especificado
			if (copy($_FILES['imgregi']['tmp_name'],$destino))
			{
					$conpl = "imagenes/registrado/".$nombre_ar;
					$db->consulta_s("UPDATE registrado set img_registrado='$conpl' where id_registrado='$_SESSION[id_core]'");
			}
		}

		// 85;
		$db->consulta_s("DELETE from relacion where id_tipo=85 and con='$_SESSION[id_core]'");
		$numt = count($_POST[temas]);
		for ($i=0; $i < $numt; $i++) {
			$db->consulta_s("INSERT into relacion(id_tipo, de, con) values(85,".$_POST[temas][$i].",$_SESSION[id_core])");
		}


		$db->consulta_s("DELETE from relacion where id_tipo=112 and con='$_SESSION[id_core]'");
		$numt = count($_POST[tperfil]);
		for ($i=0; $i < $numt; $i++) {
			$db->consulta_s("INSERT into relacion(id_tipo, de, con) values(112,".$_POST[tperfil][$i].",$_SESSION[id_core])");
		}
		?>
			<script type="text/javascript">location.href="<?php echo $dominio ?>perfil/cod4/"</script>
		<?php
	}
?>
</head>

<body >

	<?php include "include/header.php"; ?>

	<div class="conttitles">

		<div class="container">
			<h1>Mi Perfil</h1>
		</div>
	</div>
	<?php
		$db->select("registrado","*","where id_registrado='$_SESSION[id_core]'");
		$datosr = $db->fetch_array();
	?>
	<div class="divmiperfil" ng-controller="perfilController">
		<div class="container">
			<form action="" method="post" id="formPerfil" enctype="multipart/form-data">
				<input type="hidden" name="updateuser" value="1">
				<div class="input-field center-align">
					<label style="cursor: pointer;">
						<?php
							if($datosreg['img_registrado']!=""){
	                        $img = ((strpos($datosreg['img_registrado'], "http://") === 0) ||
	                                (strpos($datosreg['img_registrado'], "https://") === 0) ||
	                                (strpos($datosreg['img_registrado'], "www.") === 0)) ?
	                                $datosreg['img_registrado'] :
	                               $dominio.$datosreg['img_registrado'];
	                        }else{
	                            $img =$dominio."images/user_imagen.png";
	                        }

						?>
						<div class="cont_img" id="conimgorti" style="background-image:url(<?php echo $img ?>);"></div>
						<input type="file" name="imgregi" style="display: none;" onchange="handleFileSelect(event)">
						<input type="hidden" name="imgperf" id="imgguarda">
						Subir imagen<i class="fa fa-plus"></i>
					</label>
				</div>
				<div class="input-field">
					<label for="nombre">Tipo de perfil</label>
					<ul>
					<?php
						$db->select("tipo","*","where idr=41 order by nombre_tipo asc");
						$recod = array();
						while ($datos = $db->fetch_array()) {
							$recod[] = $datos;
						}
						foreach ($recod as $key => $datos) {
							$db->select("relacion","*","where id_tipo=112 and con='$_SESSION[id_core]' and de='$datos[id_tipo]'");
							$numd = $db->num_rows();
							$acti = "";
							if ($numd>0) {
								$acti = "checked";
							}
					?>
						<li>
							<input type="checkbox" class="tperfil" id="chectetpe<?php echo $datos[id_tipo]; ?>" value="<?php echo $datos[id_tipo]; ?>" name="tperfil[]" <?php echo $acti ?> >
							<label for="chectetpe<?php echo $datos[id_tipo]; ?>"><?php echo $datos['nombre_tipo']; ?></label>
						</li>
					<?php
						}
					?>
					</ul>
				</div>
				<div class="input-field">
					<label for="nombre">Nombre completo</label>
					<input type="text" id="nombre" name="nombre" class="required" value="<?php echo $datosr['nombre_registrado'] ?>" placeholder="Nombre completo">
				</div>
				<div class="input-field">
					<label for="email">Email</label>
					<input type="text" id="email" name="email" value="<?php echo $datosr['correo_registrado'] ?>" placeholder="Email" disabled>
				</div>
				<div class="input-field">
					<label for="nacio">Fecha nacimiento</label>
					<input type="date" id="nacio" class="datepicker required" name="nacio" value="<?php echo $datosr['nacio_registrado'] ?>" placeholder="Fecha nacimiento">
				</div>
				<div class="input-field">
					<label for="sexo">Sexo</label>
					<input type="radio" id="sexof" class="sexo" name="sexo" value="F"  <?php if($datosr['sexo_registrado']==F){ echo "checked";} ?>>
					<label for="sexof">Femenino</label>
					<input type="radio" id="sexom" class="sexo" name="sexo" value="M"  <?php if($datosr['sexo_registrado']==M){ echo "checked";} ?>>
					<label for="sexom">Maculino</label>
				</div>
				<div class="input-field">
					<label for="pais">País</label>
					<select name="pais" id="pais" class="required" ng-model="paisList" ng-change="paiselect(paisList)" >
						<option value="">Seleccionar país</option>
						<?php
							$db->select("pais","*","order by nombre_pais asc");
							while ($datos = $db->fetch_array()) {
						?>
						<option value="<?php echo $datos['codigo_pais'] ?>"><?php echo $datos['nombre_pais'] ?></option>
						<?php
							}
						?>
					</select>
				</div>
				<div class="input-field">
					<label for="departamento">Departamento</label>
					<select name="departamento" id="departamento" class="required" ng-model="departamentolist" ng-change="departselect(departamentolist)" >
						<option value="">Seleccionar departamento</option>
						<option ng-repeat="option in departamentoList" value="{{option.id_departamento}}">{{option.nombre_departamento}}</option>
					</select>
				</div>
				<div class="input-field">
					<label for="ciudad">Ciudad</label>
					<select name="ciudad" class="required" id="ciudad" >
						<option value="">Seleccionar ciudad</option>
						<option ng-repeat="option in ciudadList" value="{{option.id_ciudad}}">{{option.nombre_ciudad}}</option>
					</select>
				</div>
				<div class="input-field">
					<label for="web">Url sito web</label>
					<input type="text" id="web" name="web" value="<?php echo $datosr['web_registrado'] ?>" placeholder="Url sito web">
				</div>
				<div class="input-field">
					<label for="trabaja">Trabaja</label>
					<input type="radio" ng-click="ftrba(1)" id="trabajas" class="trabaja" name="trabaja" value="1" <?php if($datosr['esposa_registrado']==1){ echo "checked";} ?> >
					<label for="trabajas" >Si</label>
					<input type="radio" ng-click="ftrba(2)" id="trabajan" class="trabaja" name="trabaja" value="2"  <?php if($datosr['esposa_registrado']==2){ echo "checked";} ?>>
					<label for="trabajan">No</label>
				</div>
				<div id="contempr" <?php if($datosr['esposa_registrado']!=1){ ?> style="display: none;" <?php } ?> >
					<div class="input-field">
						<label for="empresa">Nombre empresa</label>
						<input type="text" name="empresa" value="<?php echo $datosr['empresa_registrado'] ?>" placeholder="Nombre empresa">
					</div>
					<div class="input-field">
						<label for="cargo">Cargo empresa</label>
						<input type="text" name="cargo" id="cargo" value="<?php echo $datosr['cargo_registrado'] ?>" placeholder="Cargo empresa">
					</div>
					<div class="input-field">
						<label for="desenpenia">En que se desempeña en la empresa?</label>
						<select name="desenpenia">
							<option value="">Seleccionar</option>
							<?php
								$db->select("tipo","*","where idr=37 order by nombre_tipo asc");
								$recod = array();
								while ($datos = $db->fetch_array()) {
									$recod[] = $datos;
								}
								foreach ($recod as $key => $datos) {

							?>
								<option value="<?php echo $datos[id_tipo]; ?>" <?php if($datosr['perfil_registrado']==$datos[id_tipo]){ echo "selected"; } ?> ><?php echo $datos['nombre_tipo']; ?></option>
							<?php
								}
							?>
						</select>
					</div>
				</div>
				<div class="input-field">
					<label for="empresa">Seleccione tenemas que sean de su interes</label>
					<?php
						$db->select("tipo","*","where idr=38 order by nombre_tipo asc");
						$recod = array();
						while ($datos = $db->fetch_array()) {
							$recod[] = $datos;
						}
						foreach ($recod as $key => $datos) {
							$db->select("relacion","*","where id_tipo=85 and con='$_SESSION[id_core]' and de='$datos[id_tipo]'");
							$numd = $db->num_rows();
							$acti = "";
							if ($numd>0) {
								$acti = "checked";
							}
					?>
						<li>
							<input type="checkbox" class="temainter" id="checte<?php echo $datos[id_tipo]; ?>" value="<?php echo $datos[id_tipo]; ?>" name="temas[]" <?php echo $acti ?> >
							<label for="checte<?php echo $datos[id_tipo]; ?>"><?php echo $datos['nombre_tipo']; ?></label>
						</li>
					<?php
						}
					?>
				</div>
				<div class="input-field">
					<label for="descripcion">Descripción personal</label>
					<textarea name="descripcion" class="materialize-textarea required" ><?php echo $datosr['mensaje_registrado'] ?></textarea>
				</div>
				<div class="input-field">
					<button class="btn ">GUARDAR información</button>
				</div>
				<br><br>
			</form>
		</div>
	</div>
	<script type="text/javascript">
		$(function(){
			$("#formPerfil").submit(function(){
				var tp=0;
				$(".tperfil").each(function(){
					if ($(this).is(":checked")){ tp++; }
				})
				if (tp==0){
					swal('Error', 'Falta seleccionar tipo de perfil','error');
					return false;
				}
				if (!vacios("#formPerfil")) {return false;}
				var tp=0;
				$(".sexo").each(function(){
					if ($(this).is(":checked")){ tp++; }
				})
				if (tp==0){
					swal('Error', 'Falta seleccionar sexo','error');
					return false;
				}

				var tp=0;
				$(".trabaja").each(function(){
					if ($(this).is(":checked")){ tp++; }
				})
				if (tp==0){
					swal('Error', 'Falta seleccionar si trabaja','error');
					return false;
				}

				var tp=0;
				$(".temainter").each(function(){
					if ($(this).is(":checked")){ tp++; }
				})
				if (tp==0){
					swal('Error', 'Falta seleccionar temas de interes','error');
					return false;
				}
			})
			 $('.datepicker').pickadate({
			 	format:"yyyy-mm-dd",
			    selectMonths: true, // Creates a dropdown to control month
			    year:2017,
			    selectYears: 100 // Creates a dropdown of 15 years to control year
			  });
		})
		//evento añadir imagen
	if(window.FormData){
        formdata = new FormData();
    }
    function handleFileSelect(evt) {
        var files = evt.target.files; // FileList object

        // Loop through the FileList and render image files as thumbnails.
        for (var i = 0, f; f = files[i]; i++) {

          if( (f.type.toLowerCase() == "image/JPEG") || (f.type.toLowerCase() == "image/jpeg") || (f.type.toLowerCase() == "image/jpg") || (f.type.toLowerCase() == "image/JPG") || (f.type.toLowerCase() == "image/png") || (f.type.toLowerCase() == "image/PNG") || (f.type.toLowerCase() == "image/gif") || (f.type.toLowerCase() == "image/GIF") ) {

                //si la imagen es mayor a 1024 kb
                console.log(f.size);
                if((f.size > 1024000 )){

                    alert("la Imágen "+f.name+" excede el peso permitido ("+Math.round((f.size)/1024)+" Kb), el peso máximo permitido es de 1024 Kb (1 Mb)");
                    return false;
                }
            }
            else{
                alert("Solo se permiten subir imágenes en formato JPG,PNG");
                return false;
            }


          var reader = new FileReader();

          // Closure to capture the file information.
          reader.onload = (function(theFile) {
            formdata.append('imagen', theFile);
            return function(e) {
              imagen = e.target.result;
              $("#imgguarda").val(imagen);
              $("#conimgorti").css({"background-image":"url("+imagen+")"});

            };
          })(f);

          // Read in the image file as a data URL.
          reader.readAsDataURL(f);
        }
    }
		var pais = "<?php echo $datosr['pais_registrado'] ?>";
		var departamento = "<?php echo $datosr['departamento_registrado'] ?>";
		var ciudad = "<?php echo $datosr['ciudad_registrado'] ?>";

		ang.controller('perfilController', function($scope, $http) {
			console.log(pais);
			if (pais!="") {
				setTimeout(function(){
					$("#pais option[value="+pais+"]").attr('selected','selected');
					$("#pais").change();
				},200);
			}
			$scope.paiselect = function(da){

			    	$http.get("<?php echo $dominio ?>lib/ajax_hlo.php?cod=departamentos&paisd="+da)
				    .then(function(response) {
				    	$scope.departamentoList = response.data;
				    	if (departamento!=""){
				    		setTimeout(function(){
				    			$("#departamento option[value="+departamento+"]").attr('selected','selected');
				    			$("#departamento").change();
				    		},100)
				    	}


				    });
			    }
			    $scope.departselect = function(da){
			    	$http.get("<?php echo $dominio ?>lib/ajax_hlo.php?cod=ciudads&depatar="+da)
				    .then(function(response) {
				    	$scope.ciudadList = response.data
				    	if (ciudad!="") {
					    	setTimeout(function(){
					    		$("#ciudad option[value="+ciudad+"]").attr('selected','selected');
					    	},100)
					    }
				    });
			    }
			    $scope.ftrba = function(d){
			    	if (d==1) {
			    		$("#contempr").show();
			    	} else{
			    		$("#contempr").hide();
			    	}
			    }
		})
	</script>

	<?php include "include/footer.php"; ?>

</body>

</html>

<?php include "include/includes.php"; ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#load').click(function(){
			var loading = false;
			var cant_tanda = $("#cant_tanda").val();
			var total = Math.ceil($('#total_rows').val()/cant_tanda);
			var page = $('#page').val();
			var condicion = $('#condicion').val();
			var ordenamiento = $('#ordenamiento').val();
			if(page <= total && loading==false){
				loading = true;
				$('#load-image').show();
				$.ajax({
					type: "POST",
					url: "<?php echo $dominio; ?>lib/task/server.php",
					data: {
						action: 'last-evento',
						page: page,
						condicion: condicion,
						cant_tanda: cant_tanda,
						ordenamiento: ordenamiento
					},				
					success: function(data){
						$('#list-eventos').append(data['news']);
						$('#load-image').hide();
						page++;
						$('#page').val(page);
						$("html, body").animate({scrollTop: $(document).height()-900}, 500);
						loading = false;
						if(page >= total){
							$('#load').hide();
						}
					}
				});
			}else{
				$('#load').hide();
			}
		});
	});
</script>

</head>
<body >
	<?php $marca=4; include "include/header.php"; ?>
	<div class="conttitles">
		<div class="container"> 
			<h1>Eventos</h1>
		</div>
	</div>
	<div class="conteventos">
		<?php
			$condicion = "";
			$ordenamiento = " ORDER BY v.evento_matrix DESC";
			/*categoria*/
			if(isset($_GET['id_categoria'])){
				$_SESSION['categoria_eventos'] = $_GET['id_categoria'];
			}

			if(isset($_SESSION['categoria_eventos']) && $_SESSION['categoria_eventos'] != ""){
				$condicion = " AND c.id_categoria = '{$_SESSION['categoria_eventos']}' ";
			}
			/*fin categoria*/

			/*fecha desde*/
			if(isset($_GET['fecha_desde'])){
				$_SESSION['fecha_desde_evento'] = $_GET['fecha_desde'];
			}

			if(isset($_SESSION['fecha_desde_evento']) && $_SESSION['fecha_desde_evento'] != ""){
				$condicion .= " AND v.evento_matrix >= '{$_SESSION['fecha_desde_evento']}'";
			}
			/*fin fecha desde*/

			/*fecha hasta*/
			if(isset($_GET['fecha_hasta'])){
				$_SESSION['fecha_hasta_evento'] = $_GET['fecha_hasta'];
			}

			if(isset($_SESSION['fecha_hasta_evento']) && $_SESSION['fecha_hasta_evento'] != ""){
				$condicion .= " AND v.evento_matrix <= '{$_SESSION['fecha_hasta_evento']}'";
			}
			/*fin fecha hasta*/

			/*order*/
			if(isset($_GET['order'])) {
				$_SESSION['ordenamiento'] = $_GET['order'];
			}

			if(isset($_SESSION['ordenamiento']) && $_SESSION['ordenamiento'] != ""){
				$db->select("tipo","valor_tipo"," where id_tipo = {$_SESSION['ordenamiento']}");
				$row = $db->fetch_assoc();
				$ordenamiento = $row['valor_tipo'];
			}
			/*fin order*/
		?>
		<div class="container">
			<div class="conbusca">	
				<div class="contfo">			
					<form>
						Tipo de evento
						<select id="sel-tipo-evento" onchange="location = this.value">
							<option value="<?php echo $dominio; ?>eventos.php?id_categoria=">Tipo de evento</option>
							<?php
								$db->select("vevento v, categoria c", "c.id_categoria, c.amigable_categoria, c.nombre_categoria", "WHERE v.id_categoria = c.id_categoria GROUP BY c.id_categoria ORDER BY c.ubica_categoria");
								/*$db->last_query();*/
								while ($row_cat = $db->fetch_array()) {
							?>
									<option value="<?php echo $dominio;?>eventos.php?amigable_categoria=<?php echo $row_cat['amigable_categoria']; ?>&id_categoria=<?php echo $row_cat['id_categoria']; ?>"
										<?php 
											if ($_SESSION['categoria_eventos']  == $row_cat['id_categoria']) {
													echo 'selected';
											}
										?>><?php echo $row_cat['nombre_categoria']; ?></option>
							<?php
								}
							?>
						</select>
						Ordenar por
						<select onchange="location = this.value">
							<option value="<?php echo $dominio; ?>eventos.php?order=">Ordenar por</option>
							<?php 
								$db->select("tipo","id_tipo, nombre_tipo","WHERE idr=32");
								/*$db->last_query();*/
								while($row = $db->fetch_array()){
							?>
									<option value="<?php echo $dominio;?>eventos.php?order=<?php echo $row['id_tipo'];?>"
										<?php
											if ($_SESSION['ordenamiento'] == $row['id_tipo']){
												echo 'selected';
											}
										?>>
										<?php echo $row['nombre_tipo'];?>
									</option>
							<?php
								}	
							?>
						</select>
					</form>
					<div class="vist">
						Vista: <span class="clvistas li" rel="list"></span> <span class="clvistas cua active" rel="cua"></span>
					</div>
				</div>

				<div class="contfo">
					<form>
						Filtrar por fecha: <span></span> desde
						<select onchange="location = this.value">
							<option value="<?php echo $dominio; ?>eventos.php?fecha_desde=">Desde</option>
							<?php
								$db->select("vevento v", "DISTINCT(Date_format(v.evento_matrix,'%d/%c/%Y')) as fecha, Date_format(v.evento_matrix,'%Y-%c-%d') as evento_matrix", "ORDER BY evento_matrix");
								/*$db->last_query();*/
								while($row = $db->fetch_array()){
							?>
									<option value="<?php echo $dominio; ?>eventos.php?fecha_desde=<?php echo $row['evento_matrix']; ?>" <?php if($_SESSION['fecha_desde_evento'] == $row['evento_matrix']){ echo "selected"; } ?>><?php echo $row['fecha']; ?></option>
							<?php
								}
							?>
						</select>

						hasta

						<select onchange="location = this.value">
							<option value="<?php echo $dominio; ?>eventos.php?fecha_hasta=">Hasta</option>
							<?php
								$db->select("vevento v", "DISTINCT(Date_format(v.evento_matrix,'%d/%c/%Y')) as fecha, Date_format(v.evento_matrix,'%Y-%c-%d') as evento_matrix", "ORDER BY evento_matrix");
								/*$db->last_query();*/
								while($row = $db->fetch_array()){
							?>
									<option value="<?php echo $dominio; ?>eventos.php?fecha_hasta=<?php echo $row['evento_matrix']; ?>" <?php if($_SESSION['fecha_hasta_evento'] == $row['evento_matrix']){ echo "selected"; } ?>><?php echo $row['fecha']; ?></option>
							<?php
								}
							?>
							<!--<option>01/01/1990</option>-->
						</select>
					</form>
				</div>
			</div>
			<ul class="listeventos row cuaevento " id="list-eventos"> 
				<?php
					$cant_tanda = 20;
					$db->select("vevento v, categoria c", "v.id_matrix", "WHERE v.id_categoria = c.id_categoria {$condicion} {$ordenamiento}");
					$num_rows = $db->num_rows();
					$db->select("vevento v, categoria c", "v.id_matrix, v.nombre_matrix, v.amigable_matrix, v.img_matrix, v.descripcion_matrix, v.evento_matrix, v.ciudad_matrix, Date_format(v.evento_matrix,'%Y') year, Date_format(v.evento_matrix,'%d') day, Date_format(v.evento_matrix,'%c') month", "WHERE v.id_categoria = c.id_categoria AND evento_matrix > CURDATE() {$condicion} {$ordenamiento} LIMIT {$cant_tanda}");
					/*$db->last_query();*/
					while($row = $db->fetch_array()){
						$mes=$row['month'];
				?>
						<li class="items col s12 m6 l4">
							<div class="cont">
								<div class="row">
									<div class="conimg col s12 m12 l4">
										<div class="imgbg" style="background-image: url(<?php echo $dominio; ?>imagenes/evento/imagen1/<?php echo $row['img_matrix']; ?>);"></div>
									</div>
									<div class="contxt col s12 m12 l8 animate">
										<h3><?php echo $row['nombre_matrix']; ?></h3>
										<div class="contmacal">
											<div class="col s12 m12 l6">
												<img src="<?php echo $dominio; ?>images/icomap1.png" alt="" title=""> <span><?php echo $row['ciudad_matrix']; ?></span>
											</div>
											<div class="col s12 m12 l6">
												<img src="<?php echo $dominio; ?>images/icomap2.png" alt="" title=""> <?php echo $row['day'].' '.$mesAbre[$mes].' '.$row['year'];?>
											</div>
										</div>
										<p><?php echo substr($row['descripcion_matrix'], 0, 145); ?></p>
										<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod73/" class="link">Leer Más</a>
										<div class="lifle">
											<a href="<?php echo $dominio.$row['amigable_matrix']; ?>/<?php echo $row['id_matrix']; ?>/cod73/" ><img src="<?php echo $dominio; ?>images/flecharara.png" alt="<?php echo $row['nombre_matrix']; ?>" title="<?php echo $row['nombre_matrix']; ?>"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
				<?php
					}
				?>
			</ul>
			<input type="hidden" id="total_rows" value="<?php echo $num_rows; ?>" />
			<input type="hidden" id="cant_tanda" value="<?php echo $cant_tanda; ?>" />
			<input type="hidden" id="condicion" value="<?php echo $condicion; ?>" />
			<input type="hidden" id="ordenamiento" value="<?php echo $ordenamiento; ?>" />
			<input type="hidden" id="page" value="1"/>			
		</div>
	</div>
	<?php 
		if($num_rows > $cant_tanda){
	?>
			<div class="creacalifica">
				<i class="fa fa-spinner fa-pulse fa-3x fa-fw" id="load-image" style="display:none;"></i><br>
				<a id="load" href="" onclick="return false;" href="" class="link">Cargas Más</a>
			</div>
	<?php
		}
	?>
	<?php include "include/suscribir.php"; ?>
	<?php include "include/footer.php"; ?>
</body>
</html>